
      

<?php
date_default_timezone_set('America/La_paz');
?>

    
     <div id="wrapper"> 

       

        <!-- Content Wrapper -->
       

            <!-- Main Content -->
           

                <!-- Topbar -->
                <!-- <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">


                <!-- </nav>  -->
                <!-- End of Topbar -->

                <!-- Begin Page Content -->

                    <!-- Page Heading -->
                    <!-- <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Salon</h1>
                        <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
                                class="fas fa-download fa-sm text-white-50"></i> Generate Report</a>
                    </div> -->

                    <!-- Content Row -->
                   

                    <!-- Content Row -->


                        <!-- Area Chart -->
                        <div class="col-xl-9 col-lg-7">
                            <div class="card shadow mb-4">
                                <!-- Card Header - Dropdown -->
                                <div
                                    class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 class="m-0 font-weight-bold text-primary">Mapa-Escenario</h6>
                                    <div class="dropdown no-arrow">
                                        <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink"
                                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            <i class="fas fa-ellipsis-v fa-sm fa-fw text-gray-400"></i>
                                        </a>
                                        <div class="dropdown-menu dropdown-menu-right shadow animated--fade-in"
                                            aria-labelledby="dropdownMenuLink">
                                            <div class="dropdown-header">Dropdown Header:</div>
                                            <a class="dropdown-item" href="#">Action</a>
                                            <a class="dropdown-item" href="#">Another action</a>
                                            <div class="dropdown-divider"></div>
                                            <a class="dropdown-item" href="#">Something else here</a>
                                        </div>
                                    </div>
                                </div>
                                <!-- Card Body -->
                                <!-- <div class="img" >



                                    <img src="<?php echo base_url(); ?>starbootstrap/img/mapa.png" alt="" whidth ="10px">


                                </div> -->

                    

                                <!-- desde aca ers la imagen svg muy largo porsierto -->

                                <?xml version="1.0" encoding="utf-8"?>
                                <!-- Generator: Adobe Illustrator 16.0.3, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
                                <!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">


<!-- desde aca se viene el svg nuevo -->
                             <svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                             width="100%" height="100%" viewBox="0 0 800 760" enable-background="new 0 0 800 760" xml:space="preserve">
                                <a xlink:href="" xlink:title="Mesa 1" class="dropdown-item" href="<?= base_url ('index.php/evento/evento1?mesa=1') ?>" >
                                <rect id="mesa1" x="405.061" y="40.925" transform="matrix(0.515 -0.8572 0.8572 0.515 166.7904 395.6567)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="55.998" height="19.001"/>
    
                                    <rect class="silla" id="silla10" x="448.147" y="11.496" transform="matrix(0.5149 -0.8572 0.8572 0.5149 205.2334 396.6935)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10" height="11.001"/>
                                    <rect class="silla" id="silla11" x="422.764" y="14.911" transform="matrix(0.5151 -0.8571 0.8571 0.5151 189.9377 376.5524)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="9.999" height="10.998"/>
                                    <rect class="silla" id="silla12" x="459.192" y="36.299" transform="matrix(0.515 -0.8572 0.8572 0.515 188.8602 418.4051)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="silla13" x="414.794" y="27.34" transform="matrix(0.515 -0.8572 0.8572 0.515 175.6765 376.1869)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="10.998"/>
                                    <rect class="silla" id="silla14" x="451.224" y="48.728" transform="matrix(0.5149 -0.8572 0.8572 0.5149 174.6355 418.0705)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11" height="12"/>
                                    <rect class="silla" id="silla15" x="406.554" y="41.052" transform="matrix(0.515 -0.8572 0.8572 0.515 159.9579 375.7992)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="11"/>
                                    <rect class="silla" id="silla16" x="442.983" y="62.442" transform="matrix(0.515 -0.8572 0.8572 0.515 158.8291 417.6154)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="12"/>
                                    <rect class="silla" id="silla17" x="399.072" y="54.339" transform="matrix(0.515 -0.8572 0.8572 0.515 144.6951 375.3997)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10" height="11.001"/>
                                    <rect class="silla" id="silla18" x="435.5" y="75.729" transform="matrix(0.515 -0.8572 0.8572 0.515 143.5723 417.2193)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="silla19" x="408.489" y="77.498" transform="matrix(0.5151 -0.8572 0.8572 0.5151 129.3773 394.6737)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10" height="10.998"/>
                                    <text transform="matrix(1 0 0 1 430.7461 53.1758)" font-family="'MyriadPro-Regular'" font-size="12">1</text>
                                </a>

                                <a xlink:href="" xlink:title="Mesa 2" class="dropdown-item" href="<?= base_url ('index.php/evento/evento1?mesa=2') ?>" >
                                    <rect id="mesa2" x="458.061" y="69.926" transform="matrix(0.515 -0.8572 0.8572 0.515 167.6368 455.1513)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="55.999" height="19.001"/>
                                    <rect class="silla" id="silla20" x="501.147" y="40.496" transform="matrix(0.5149 -0.8572 0.8572 0.5149 206.0822 456.193)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10" height="11.001"/>
                                    <rect class="silla" id="silla21" x="475.764" y="43.911" transform="matrix(0.5151 -0.8571 0.8571 0.5151 190.7719 436.0364)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="9.999" height="10.998"/>
                                    <rect class="silla" id="silla22" x="512.192" y="65.299" transform="matrix(0.515 -0.8572 0.8572 0.515 189.7157 477.9073)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10.001" height="12"/>
                                    <rect class="silla" id="silla23" x="467.794" y="56.339" transform="matrix(0.515 -0.8572 0.8572 0.515 176.5216 435.6802)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="10.998"/>
                                    <rect class="silla" id="silla24" x="504.224" y="77.728" transform="matrix(0.5149 -0.8572 0.8572 0.5149 175.4849 477.5719)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11" height="12"/>
                                    <rect class="silla" id="silla25" x="459.554" y="70.052" transform="matrix(0.5149 -0.8572 0.8572 0.5149 160.8142 435.3046)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="11"/>
                                    <rect class="silla" id="silla26" x="495.983" y="91.442" transform="matrix(0.515 -0.8572 0.8572 0.515 159.674 477.1089)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="12"/>
                                    <rect class="silla" id="silla27" x="452.072" y="83.339" transform="matrix(0.515 -0.8572 0.8572 0.515 145.5341 434.8904)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="9.999" height="11.001"/>
                                    <rect class="silla" id="silla28" x="488.501" y="104.729" transform="matrix(0.5151 -0.8572 0.8572 0.5151 144.4081 476.7047)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="silla29" x="461.489" y="106.499" transform="matrix(0.5151 -0.8571 0.8571 0.5151 130.2044 454.1496)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="9.999" height="10.998"/>
                                    <text transform="matrix(1 0 0 1 483.8418 82.9976)" font-family="'MyriadPro-Regular'" font-size="12">2</text>

                                </a>

                                <a xlink:href="" xlink:title="Mesa 3" class="dropdown-item" href="<?= base_url ('index.php/evento/evento1?mesa=3') ?>" >
                                   <rect id="mesa3" x="515.061" y="102.926" transform="matrix(0.515 -0.8572 0.8572 0.515 166.9929 520.0132)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="55.999" height="19.001"/>
                                    <rect class="silla" id="silla30" x="558.147" y="73.496" transform="matrix(0.5149 -0.8572 0.8572 0.5149 205.4421 521.0618)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10" height="11.001"/>
                                    <rect class="silla" id="silla31" x="532.764" y="76.911" transform="matrix(0.5151 -0.8571 0.8571 0.5151 190.1259 500.8946)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="9.999" height="10.998"/>
                                    <rect class="silla" id="silla32" x="569.192" y="98.299" transform="matrix(0.515 -0.8572 0.8572 0.515 189.0729 542.7714)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10.001" height="12"/>
                                    <rect class="silla" id="silla33" x="524.794" y="89.339" transform="matrix(0.515 -0.8572 0.8572 0.515 175.8777 500.5421)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="10.998"/>
                                    <rect class="silla" id="silla34" x="561.224" y="110.728" transform="matrix(0.5149 -0.8572 0.8572 0.5149 174.8458 542.4426)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11" height="12"/>
                                    <rect class="silla" id="silla35" x="516.554" y="103.052" transform="matrix(0.5149 -0.8572 0.8572 0.5149 160.1742 500.1735)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="11"/>
                                    <rect class="silla" id="silla36" x="552.983" y="124.442" transform="matrix(0.515 -0.8572 0.8572 0.515 159.0301 541.9708)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="12"/>
                                    <rect class="silla" id="silla37" x="509.072" y="116.339" transform="matrix(0.515 -0.8572 0.8572 0.515 144.8924 499.7563)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="9.999" height="11.001"/>
                                    <rect class="silla" id="silla38" x="545.501" y="137.729" transform="matrix(0.5151 -0.8572 0.8572 0.5151 143.7638 541.5657)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="silla39" x="518.489" y="139.499" transform="matrix(0.5151 -0.8571 0.8571 0.5151 129.5584 519.0078)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="9.999" height="10.998"/>
                                    <text transform="matrix(1 0 0 1 539.7793 116.1533)" font-family="'MyriadPro-Regular'" font-size="12">3</text>

                                </a>

                                <a xlink:href="" xlink:title="Mesa 4" class="dropdown-item" href="<?= base_url ('index.php/evento/evento1?mesa=4') ?>" >
                                    <rect id="mesa4" x="572.061" y="134.926" transform="matrix(0.515 -0.8572 0.8572 0.515 167.2061 584.39)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="55.999" height="19.001"/>
                                    <rect class="silla" id="silla40" x="615.147" y="105.496" transform="matrix(0.5149 -0.8572 0.8572 0.5149 205.6592 585.4456)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10" height="11.001"/>
                                    <rect class="silla" id="silla41" x="589.764" y="108.911" transform="matrix(0.5151 -0.8571 0.8571 0.5151 190.3371 565.2678)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="9.999" height="10.998"/>
                                    <rect class="silla" id="silla42" x="626.192" y="130.299" transform="matrix(0.515 -0.8572 0.8572 0.515 189.2874 607.1504)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10.001" height="12"/>
                                    <rect class="silla" id="silla43" x="581.794" y="121.339" transform="matrix(0.515 -0.8572 0.8572 0.515 176.091 564.9189)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="10.998"/>
                                    <rect class="silla" id="silla44" x="618.224" y="142.728" transform="matrix(0.5149 -0.8572 0.8572 0.5149 175.064 606.8281)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11" height="12"/>
                                    <rect class="silla" id="silla45" x="573.554" y="135.052" transform="matrix(0.5149 -0.8572 0.8572 0.5149 160.3914 564.5574)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="11"/>
                                    <rect class="silla" id="silla46" x="609.983" y="156.442" transform="matrix(0.515 -0.8572 0.8572 0.515 159.2433 606.3477)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="12"/>
                                    <rect class="silla" id="silla47" x="566.072" y="148.339" transform="matrix(0.515 -0.8572 0.8572 0.515 145.1079 564.1371)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="9.999" height="11.001"/>
                                    <rect class="silla" id="silla48" x="602.501" y="169.729" transform="matrix(0.5151 -0.8572 0.8572 0.5151 143.9766 605.9419)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="silla49" x="575.489" y="171.499" transform="matrix(0.5151 -0.8571 0.8571 0.5151 129.7696 583.3811)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="9.999" height="10.998"/>
                                    <text transform="matrix(1 0 0 1 596.7461 146.5088)" font-family="'MyriadPro-Regular'" font-size="12">4</text>

                                </a>
                                <a xlink:href="" xlink:title="Mesa 5" class="dropdown-item" href="<?= base_url ('index.php/evento/evento1?mesa=5') ?>" >
                                   
                                    <rect id="mesa5" x="407.061" y="152.926" transform="matrix(0.515 -0.8572 0.8572 0.515 71.7596 451.6873)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="55.999" height="19.001"/>
                                    <rect class="silla" id="silla50" x="450.147" y="123.496" transform="matrix(0.5149 -0.8572 0.8572 0.5149 110.1944 452.7344)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10" height="11.001"/>
                                    <rect class="silla" id="silla51" x="424.764" y="126.911" transform="matrix(0.5151 -0.8571 0.8571 0.5151 94.9001 432.5695)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="9.999" height="10.998"/>
                                    <rect class="silla" id="silla52" x="461.192" y="148.299" transform="matrix(0.515 -0.8572 0.8572 0.515 93.8351 474.445)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10.001" height="12"/>
                                    <rect class="silla" id="silla53" x="416.794" y="139.339" transform="matrix(0.515 -0.8572 0.8572 0.515 80.6443 432.2162)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="10.998"/>
                                    <rect class="silla" id="silla54" x="453.224" y="160.728" transform="matrix(0.5149 -0.8572 0.8572 0.5149 79.5944 474.1147)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11" height="12"/>
                                    <rect class="silla" id="silla55" x="408.554" y="153.052" transform="matrix(0.5149 -0.8572 0.8572 0.5149 64.9264 431.8461)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="11"/>
                                    <rect class="silla" id="silla56" x="444.983" y="174.442" transform="matrix(0.515 -0.8572 0.8572 0.515 63.7966 473.6449)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="12"/>
                                    <rect class="silla" id="silla57" x="401.072" y="166.339" transform="matrix(0.515 -0.8572 0.8572 0.515 49.6506 431.4295)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="9.999" height="11.001"/>
                                    <rect class="silla" id="silla58" x="437.501" y="187.729" transform="matrix(0.5151 -0.8572 0.8572 0.5151 48.532 473.24)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="silla59" x="410.489" y="189.499" transform="matrix(0.5151 -0.8571 0.8571 0.5151 34.3326 450.6827)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="9.999" height="10.998"/>
                                    <text transform="matrix(1 0 0 1 433.5107 167.6484)" font-family="'MyriadPro-Regular'" font-size="12">5</text>

                                    </a>
                                <a xlink:href="" xlink:title="Mesa 6" class="dropdown-item" href="<?= base_url ('index.php/evento/evento1?mesa=6') ?>" >
                                <rect id="mesa6" x="459.061" y="184.926" transform="matrix(0.515 -0.8572 0.8572 0.515 69.548 511.7784)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="55.999" height="19.001"/>
                                    <rect class="silla" id="silla60" x="502.147" y="155.496" transform="matrix(0.5149 -0.8572 0.8572 0.5149 107.9863 512.832)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10" height="11.001"/>
                                    <rect class="silla" id="silla61" x="476.764" y="158.911" transform="matrix(0.5151 -0.8571 0.8571 0.5151 92.6867 492.6571)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="9.999" height="10.998"/>
                                    <rect class="silla" id="silla62" x="513.192" y="180.299" transform="matrix(0.515 -0.8572 0.8572 0.515 91.6246 534.5381)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10.001" height="12"/>
                                    <rect class="silla" id="silla63" x="468.794" y="171.339" transform="matrix(0.515 -0.8572 0.8572 0.515 78.4327 492.3073)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="10.998"/>
                                    <rect class="silla" id="silla64" x="505.224" y="192.728" transform="matrix(0.5149 -0.8572 0.8572 0.5149 77.3871 534.2141)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11" height="12"/>
                                    <rect class="silla" id="silla65" x="460.554" y="185.052" transform="matrix(0.5149 -0.8572 0.8572 0.5149 62.7183 491.9438)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="11"/>
                                    <rect class="silla" id="silla66" x="496.983" y="206.442" transform="matrix(0.515 -0.8572 0.8572 0.515 61.5851 533.736)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="12"/>
                                    <rect class="silla" id="silla67" x="453.072" y="198.339" transform="matrix(0.515 -0.8572 0.8572 0.515 47.4411 491.5244)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="9.999" height="11.001"/>
                                    <rect class="silla" id="silla68" x="493.501" y="219.729" transform="matrix(0.5151 -0.8572 0.8572 0.5151 48.2598 536.759)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="silla69" x="462.489" y="221.499" transform="matrix(0.5151 -0.8571 0.8571 0.5151 32.1192 510.7704)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="9.999" height="10.998"/>
                                    <text transform="matrix(1 0 0 1 485.7822 196.7207)" font-family="'MyriadPro-Regular'" font-size="12">6</text>
    
                                </a>
                                <a xlink:href="" xlink:title="Mesa 7" class="dropdown-item" href="<?= base_url ('index.php/evento/evento1?mesa=7') ?>" >
                                    <rect id="mesa7" x="511.061" y="216.926" transform="matrix(0.515 -0.8572 0.8572 0.515 67.3365 571.8694)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="55.999" height="19.001"/>
                                    <rect class="silla" id="silla70" x="554.147" y="187.496" transform="matrix(0.5149 -0.8572 0.8572 0.5149 105.7781 572.9297)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10" height="11.001"/>
                                    <rect class="silla" id="silla71" x="528.764" y="190.911" transform="matrix(0.5151 -0.8571 0.8571 0.5151 90.4734 552.7448)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="9.999" height="10.998"/>
                                    <rect class="silla" id="silla72" x="565.192" y="212.299" transform="matrix(0.515 -0.8572 0.8572 0.515 89.4142 594.6312)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10.001" height="12"/>
                                    <rect class="silla" id="silla73" x="520.794" y="203.339" transform="matrix(0.515 -0.8572 0.8572 0.515 76.2212 552.3984)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="10.998"/>
                                    <rect class="silla" id="silla74" x="557.224" y="224.728" transform="matrix(0.5149 -0.8572 0.8572 0.5149 75.1798 594.3135)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11" height="12"/>
                                    <rect class="silla" id="silla75" x="512.554" y="217.052" transform="matrix(0.5149 -0.8572 0.8572 0.5149 60.5102 552.0415)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="11"/>
                                    <rect class="silla" id="silla76" x="548.983" y="238.442" transform="matrix(0.515 -0.8572 0.8572 0.515 59.3736 593.8271)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="12"/>
                                    <rect class="silla" id="silla77" x="505.072" y="230.339" transform="matrix(0.515 -0.8572 0.8572 0.515 45.2315 551.6193)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="9.999" height="11.001"/>
                                    <rect class="silla" id="silla78" x="541.501" y="251.729" transform="matrix(0.5151 -0.8572 0.8572 0.5151 44.1082 593.4208)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="silla79" x="514.489" y="253.499" transform="matrix(0.5151 -0.8571 0.8571 0.5151 29.9059 570.858)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="9.999" height="10.998"/>
                                    <text transform="matrix(1 0 0 1 537.8418 229.5322)" font-family="'MyriadPro-Regular'" font-size="12">7</text>
   
                                </a>
                                <a xlink:href="" xlink:title="Mesa 8" class="dropdown-item" href="<?= base_url ('index.php/evento/evento1?mesa=8') ?>" >
                                    <rect id="mesa8" x="567.061" y="248.926" transform="matrix(0.515 -0.8572 0.8572 0.515 67.0648 635.3892)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="55.999" height="19.001"/>
                                    <rect class="silla" id="silla80" x="610.147" y="219.496" transform="matrix(0.5149 -0.8572 0.8572 0.5149 105.5102 636.4562)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10" height="11.001"/>
                                    <rect class="silla" id="silla81" x="584.764" y="222.911" transform="matrix(0.5151 -0.8571 0.8571 0.5151 90.1997 616.2609)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="9.999" height="10.998"/>
                                    <rect class="silla" id="silla82" x="621.192" y="244.299" transform="matrix(0.515 -0.8572 0.8572 0.515 89.1436 658.153)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10.001" height="12"/>
                                    <rect class="silla" id="silla83" x="576.794" y="235.339" transform="matrix(0.515 -0.8572 0.8572 0.515 75.9495 615.9182)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="10.998"/>
                                    <rect class="silla" id="silla84" x="613.224" y="256.728" transform="matrix(0.5149 -0.8572 0.8572 0.5149 74.913 657.8418)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11" height="12"/>
                                    <rect class="silla" id="silla85" x="568.554" y="249.052" transform="matrix(0.5149 -0.8572 0.8572 0.5149 60.2423 615.5681)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="11"/>
                                    <rect class="silla" id="silla86" x="604.983" y="270.442" transform="matrix(0.515 -0.8572 0.8572 0.515 59.1019 657.3469)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="12"/>
                                    <rect class="silla" id="silla87" x="561.072" y="262.339" transform="matrix(0.515 -0.8572 0.8572 0.515 44.962 615.1429)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="9.999" height="11.001"/>
                                    <rect class="silla" id="silla88" x="597.501" y="283.729" transform="matrix(0.5151 -0.8572 0.8572 0.5151 43.836 656.9398)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="silla89" x="570.489" y="285.499" transform="matrix(0.5151 -0.8571 0.8571 0.5151 29.6322 634.3741)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="9.999" height="10.998"/>
                                    <text transform="matrix(1 0 0 1 592.8418 262.1006)" font-family="'MyriadPro-Regular'" font-size="12">8</text>
    
                                </a>
                                <a xlink:href="" xlink:title="Mesa 9" class="dropdown-item" href="<?= base_url ('index.php/evento/evento1?mesa=9') ?>" >
                                    <rect id="mesa9" x="621.061" y="281.926" transform="matrix(0.515 -0.8572 0.8572 0.515 64.9659 697.6795)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="55.999" height="19.001"/>
                                    <rect class="silla" id="silla90" x="664.147" y="252.496" transform="matrix(0.5149 -0.8572 0.8572 0.5149 103.4149 698.7533)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10" height="11.001"/>
                                    <rect class="silla" id="silla91" x="638.764" y="255.911" transform="matrix(0.5151 -0.8571 0.8571 0.5151 88.0991 678.5477)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="9.999" height="10.998"/>
                                    <rect class="silla" id="silla92" x="675.192" y="277.299" transform="matrix(0.515 -0.8572 0.8572 0.515 87.0459 720.4454)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10.001" height="12"/>
                                    <rect class="silla" id="silla94" x="667.224" y="289.728" transform="matrix(0.5149 -0.8572 0.8572 0.5149 72.8186 720.1407)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11" height="12"/>
                                    <rect class="silla" id="silla93" x="630.794" y="268.339" transform="matrix(0.515 -0.8572 0.8572 0.515 73.8508 678.2086)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="10.998"/>
                                    <rect class="silla" id="silla95" x="622.554" y="282.052" transform="matrix(0.5149 -0.8572 0.8572 0.5149 58.1471 677.8654)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="11"/>
                                    <rect class="silla" id="silla96" x="658.983" y="303.442" transform="matrix(0.515 -0.8572 0.8572 0.515 57.0031 719.6373)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="12"/>
                                    <rect class="silla" id="silla97" x="615.072" y="295.339" transform="matrix(0.515 -0.8572 0.8572 0.515 42.8653 677.4373)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="9.999" height="11.001"/>
                                    <rect class="silla" id="silla98" x="651.501" y="316.729" transform="matrix(0.5151 -0.8572 0.8572 0.5151 41.7368 719.2294)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="silla99" x="624.489" y="318.499" transform="matrix(0.5151 -0.8571 0.8571 0.5151 27.5316 696.661)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="9.999" height="10.998"/>
                                    <text transform="matrix(1 0 0 1 644.8857 296.6484)" font-family="'MyriadPro-Regular'" font-size="12">9</text>
    
                                </a>
                                <a xlink:href="" xlink:title="Mesa 10" class="dropdown-item" href="<?= base_url ('index.php/evento/evento1?mesa=10') ?>" >
                                    <rect id="mesa10" x="673.061" y="314.926" transform="matrix(0.515 -0.8572 0.8572 0.515 61.8972 758.2555)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="55.999" height="19.001"/>
                                    <rect class="silla" id="silla100" x="716.147" y="285.496" transform="matrix(0.5149 -0.8572 0.8572 0.5149 100.3495 759.3361)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10" height="11.001"/>
                                    <rect class="silla" id="silla101" x="690.764" y="288.911" transform="matrix(0.5151 -0.8571 0.8571 0.5151 85.0286 739.1202)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="9.999" height="10.998"/>
                                    <rect class="silla" id="silla102" x="727.192" y="310.299" transform="matrix(0.515 -0.8572 0.8572 0.515 83.9782 781.0236)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10.001" height="12"/>
                                    <rect class="silla" id="silla103" x="682.794" y="301.339" transform="matrix(0.515 -0.8572 0.8572 0.515 70.782 738.7846)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="10.998"/>
                                    <rect class="silla" id="silla104" x="719.224" y="322.728" transform="matrix(0.5149 -0.8572 0.8572 0.5149 69.7542 780.7252)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11" height="12"/>
                                    <rect class="silla" id="silla105" x="674.554" y="315.052" transform="matrix(0.5149 -0.8572 0.8572 0.5149 55.0818 738.4481)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="11"/>
                                    <rect class="silla" id="silla106" x="710.983" y="336.442" transform="matrix(0.515 -0.8572 0.8572 0.515 53.9344 780.2133)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="12"/>
                                    <rect class="silla" id="silla107" x="667.072" y="328.339" transform="matrix(0.515 -0.8572 0.8572 0.515 39.7985 738.0172)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="9.999" height="11.001"/>
                                    <rect class="silla" id="silla108" x="703.501" y="349.729" transform="matrix(0.5151 -0.8572 0.8572 0.5151 38.6678 779.8047)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="silla109" x="676.489" y="351.499" transform="matrix(0.5151 -0.8571 0.8571 0.5151 24.4611 757.2335)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="9.999" height="10.998"/>
                                    <text transform="matrix(1 0 0 1 695.7637 326.7207)" font-family="'MyriadPro-Regular'" font-size="12">10</text>
   
                                </a>
                                <a xlink:href="" xlink:title="Mesa 11" class="dropdown-item" href="<?= base_url ('index.php/evento/evento1?mesa=11') ?>" >
                                    <rect id="mesa11" x="726.061" y="346.926" transform="matrix(0.515 -0.8572 0.8572 0.515 60.1707 819.2037)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="55.999" height="19.001"/>
                                    <rect class="silla" id="silla110" x="769.147" y="317.496" transform="matrix(0.5149 -0.8572 0.8572 0.5149 98.6265 820.2909)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10" height="11.001"/>
                                    <rect class="silla" id="silla111" x="743.764" y="320.911" transform="matrix(0.5151 -0.8571 0.8571 0.5151 83.3002 800.0651)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="9.999" height="10.998"/>
                                    <rect class="silla" id="silla112" x="780.192" y="342.299" transform="matrix(0.515 -0.8572 0.8572 0.515 82.2527 841.9738)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10.001" height="12"/>
                                    <rect class="silla" id="silla113" x="735.794" y="333.339" transform="matrix(0.515 -0.8572 0.8572 0.515 69.0555 799.7329)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="10.998"/>
                                    <rect class="silla" id="silla114" x="772.224" y="354.728" transform="matrix(0.5149 -0.8572 0.8572 0.5149 68.032 841.6818)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11" height="12"/>
                                    <rect class="silla" id="silla115" x="727.554" y="347.052" transform="matrix(0.5149 -0.8572 0.8572 0.5149 53.3587 799.4031)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="11"/>
                                    <rect class="silla" id="silla116" x="763.983" y="368.442" transform="matrix(0.515 -0.8572 0.8572 0.515 52.2079 841.1616)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="12"/>
                                    <rect class="silla" id="silla117" x="720.072" y="360.339" transform="matrix(0.515 -0.8572 0.8572 0.515 38.074 798.9693)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="9.999" height="11.001"/>
                                    <rect class="silla" id="silla118" x="756.501" y="381.729" transform="matrix(0.5151 -0.8572 0.8572 0.5151 36.9408 840.7522)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="silla119" x="729.489" y="383.499" transform="matrix(0.5151 -0.8571 0.8571 0.5151 22.7327 818.1783)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="9.999" height="10.998"/>
                                    <text transform="matrix(1 0 0 1 748.8418 361.6484)" font-family="'MyriadPro-Regular'" font-size="12">11</text>
   
                                </a>
                                <a xlink:href="" xlink:title="Mesa 12" class="dropdown-item" href="<?= base_url ('index.php/evento/evento1?mesa=12') ?>" >
                                    <rect id="mesa12" x="409.061" y="267.926" transform="matrix(0.515 -0.8572 0.8572 0.515 -25.8443 509.1715)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="55.999" height="19.001"/>
                                    <rect class="silla" id="silla120" x="452.147" y="238.496" transform="matrix(0.5149 -0.8572 0.8572 0.5149 12.5836 510.2307)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10" height="11.001"/>
                                    <rect class="silla" id="silla121" x="426.764" y="241.911" transform="matrix(0.5151 -0.8571 0.8571 0.5151 -2.7002 490.0474)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="9.999" height="10.998"/>
                                    <rect class="silla" id="silla122" x="463.192" y="263.299" transform="matrix(0.515 -0.8572 0.8572 0.515 -3.7709 531.9329)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10.001" height="12"/>
                                    <rect class="silla" id="silla123" x="418.794" y="254.339" transform="matrix(0.515 -0.8572 0.8572 0.515 -16.9597 489.7004)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="10.998"/>
                                    <rect class="silla" id="silla124" x="455.224" y="275.728" transform="matrix(0.5149 -0.8572 0.8572 0.5149 -18.0183 531.6142)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11" height="12"/>
                                    <rect class="silla" id="silla125" x="410.554" y="268.052" transform="matrix(0.5149 -0.8572 0.8572 0.5149 -32.6846 489.3425)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="11"/>
                                    <rect class="silla" id="silla126" x="446.983" y="289.442" transform="matrix(0.515 -0.8572 0.8572 0.515 -33.8073 531.1292)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="12"/>
                                    <rect class="silla" id="silla127" x="403.072" y="281.339" transform="matrix(0.515 -0.8572 0.8572 0.515 -47.9573 488.9207)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="9.999" height="11.001"/>
                                    <rect class="silla" id="silla128" x="439.501" y="302.729" transform="matrix(0.5151 -0.8572 0.8572 0.5151 -49.0712 530.7229)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="silla129" x="412.489" y="304.499" transform="matrix(0.5151 -0.8571 0.8571 0.5151 -63.2677 508.1606)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="9.999" height="10.998"/>
                                    <text transform="matrix(1 0 0 1 432.0605 279.0059)" font-family="'MyriadPro-Regular'" font-size="12">12</text>
   
                                </a>
                                <a xlink:href="" xlink:title="Mesa 13" class="dropdown-item" href="<?= base_url ('index.php/evento/evento1?mesa=13') ?>" >
                                    <rect id="mesa13" x="461.061" y="299.926" transform="matrix(0.515 -0.8572 0.8572 0.515 -28.0558 569.2626)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="55.999" height="19.001"/>
                                    <rect class="silla" id="silla130" x="504.147" y="270.496" transform="matrix(0.5149 -0.8572 0.8572 0.5149 10.3754 570.3282)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10" height="11.001"/>
                                    <rect class="silla" id="silla131" x="478.764" y="273.911" transform="matrix(0.5151 -0.8571 0.8571 0.5151 -4.9135 550.135)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="9.999" height="10.998"/>
                                    <rect class="silla" id="silla132" x="515.192" y="295.299" transform="matrix(0.515 -0.8572 0.8572 0.515 -5.9814 592.026)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10.001" height="12"/>
                                    <rect class="silla" id="silla133" x="470.794" y="286.339" transform="matrix(0.515 -0.8572 0.8572 0.515 -19.1712 549.7916)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="10.998"/>
                                    <rect class="silla" id="silla134" x="507.224" y="307.728" transform="matrix(0.5149 -0.8572 0.8572 0.5149 -20.2256 591.7136)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11" height="12"/>
                                    <rect class="silla" id="silla135" x="462.554" y="300.052" transform="matrix(0.5149 -0.8572 0.8572 0.5149 -34.8927 549.4402)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="11"/>
                                    <rect class="silla" id="silla136" x="498.983" y="321.442" transform="matrix(0.515 -0.8572 0.8572 0.515 -36.0188 591.2202)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="12"/>
                                    <rect class="silla" id="silla137" x="455.072" y="313.339" transform="matrix(0.515 -0.8572 0.8572 0.515 -50.1669 549.0156)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="9.999" height="11.001"/>
                                    <rect class="silla" id="silla138" x="491.501" y="334.729" transform="matrix(0.5151 -0.8572 0.8572 0.5151 -51.2831 590.8133)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="silla139" x="464.489" y="336.499" transform="matrix(0.5151 -0.8571 0.8571 0.5151 -65.481 568.2483)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="9.999" height="10.998"/>
                                    <text transform="matrix(1 0 0 1 483.8418 313.0059)" font-family="'MyriadPro-Regular'" font-size="12">13</text>
   
                                </a>
                                <a xlink:href="" xlink:title="Mesa 14" class="dropdown-item" href="<?= base_url ('index.php/evento/evento1?mesa=14') ?>" >
                                    <rect id="mesa14" x="513.061" y="331.926" transform="matrix(0.515 -0.8572 0.8572 0.515 -30.2674 629.3536)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="55.999" height="19.001"/>
                                    <rect class="silla" id="silla140" x="556.147" y="302.496" transform="matrix(0.5149 -0.8572 0.8572 0.5149 8.1672 630.4259)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10" height="11.001"/>
                                    <rect class="silla" id="silla141" x="530.764" y="305.911" transform="matrix(0.5151 -0.8571 0.8571 0.5151 -7.1268 610.2227)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="9.999" height="10.998"/>
                                    <rect class="silla" id="silla142" x="567.192" y="327.299" transform="matrix(0.515 -0.8572 0.8572 0.515 -8.1919 652.1191)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10.001" height="12"/>
                                    <rect class="silla" id="silla143" x="522.794" y="318.339" transform="matrix(0.515 -0.8572 0.8572 0.515 -21.3827 609.8827)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="10.998"/>
                                    <rect class="silla" id="silla144" x="559.224" y="339.728" transform="matrix(0.5149 -0.8572 0.8572 0.5149 -22.4329 651.8129)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11" height="12"/>
                                    <rect class="silla" id="silla145" x="514.554" y="332.052" transform="matrix(0.5149 -0.8572 0.8572 0.5149 -37.1008 609.5379)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="11"/>
                                    <rect class="silla" id="silla146" x="550.983" y="353.442" transform="matrix(0.515 -0.8572 0.8572 0.515 -38.2303 651.3114)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="12"/>
                                    <rect class="silla" id="silla147" x="507.072" y="345.339" transform="matrix(0.515 -0.8572 0.8572 0.515 -52.3764 609.1105)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="9.999" height="11.001"/>
                                    <rect class="silla" id="silla148" x="543.501" y="366.729" transform="matrix(0.5151 -0.8572 0.8572 0.5151 -53.495 650.9037)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="silla149" x="516.489" y="368.499" transform="matrix(0.5151 -0.8571 0.8571 0.5151 -67.6943 628.3359)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="9.999" height="10.998"/>
                                    <text transform="matrix(1 0 0 1 535.4648 344.5889)" font-family="'MyriadPro-Regular'" font-size="12">14</text>
   
                                </a>
                                <a xlink:href="" xlink:title="Mesa 15" class="dropdown-item" href="<?= base_url ('index.php/evento/evento1?mesa=15') ?>" >
                                    <rect id="mesa15" x="569.061" y="363.926" transform="matrix(0.515 -0.8572 0.8572 0.515 -30.5391 692.8734)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="55.999" height="19.001"/>
                                    <rect class="silla" id="silla150" x="612.147" y="334.496" transform="matrix(0.5149 -0.8572 0.8572 0.5149 7.8994 693.9525)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10" height="11.001"/>
                                    <rect class="silla" id="silla151" x="586.764" y="337.911" transform="matrix(0.5151 -0.8571 0.8571 0.5151 -7.4005 673.7388)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="9.999" height="10.998"/>
                                    <rect class="silla" id="silla152" x="623.192" y="359.299" transform="matrix(0.515 -0.8572 0.8572 0.515 -8.4624 715.6409)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10.001" height="12"/>
                                    <rect class="silla" id="silla153" x="578.794" y="350.339" transform="matrix(0.515 -0.8572 0.8572 0.515 -21.6544 673.4025)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="10.998"/>
                                    <rect class="silla" id="silla154" x="615.224" y="371.728" transform="matrix(0.5149 -0.8572 0.8572 0.5149 -22.6998 715.3412)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11" height="12"/>
                                    <rect class="silla" id="silla155" x="570.554" y="364.052" transform="matrix(0.5149 -0.8572 0.8572 0.5149 -37.3687 673.0645)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="11"/>
                                    <rect class="silla" id="silla156" x="606.983" y="385.442" transform="matrix(0.515 -0.8572 0.8572 0.515 -38.502 714.8312)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="12"/>
                                    <rect class="silla" id="silla157" x="563.072" y="377.339" transform="matrix(0.515 -0.8572 0.8572 0.515 -52.6459 672.6342)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="9.999" height="11.001"/>
                                    <rect class="silla" id="silla158" x="599.501" y="398.729" transform="matrix(0.5151 -0.8572 0.8572 0.5151 -53.7671 714.4227)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="silla159" x="572.489" y="400.499" transform="matrix(0.5151 -0.8571 0.8571 0.5151 -67.968 691.8521)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="9.999" height="10.998"/>
                                    <text transform="matrix(1 0 0 1 592.7637 375.7207)" font-family="'MyriadPro-Regular'" font-size="12">15</text>
    
                                </a>
                                <a xlink:href="" xlink:title="Mesa 16" class="dropdown-item" href="<?= base_url ('index.php/evento/evento1?mesa=16') ?>" >
                                    <rect id="mesa16" x="623.061" y="396.926" transform="matrix(0.515 -0.8572 0.8572 0.515 -32.6379 755.1637)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="55.999" height="19.001"/>
                                    <rect class="silla" id="silla160" x="666.147" y="367.496" transform="matrix(0.5149 -0.8572 0.8572 0.5149 5.8041 756.2496)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10" height="11.001"/>
                                    <rect class="silla" id="silla161" x="640.764" y="370.911" transform="matrix(0.5151 -0.8571 0.8571 0.5151 -9.5012 736.0256)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="9.999" height="10.998"/>
                                    <rect class="silla" id="silla162" x="677.192" y="392.299" transform="matrix(0.515 -0.8572 0.8572 0.515 -10.5601 777.9333)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10.001" height="12"/>
                                    <rect class="silla" id="silla163" x="632.794" y="383.339" transform="matrix(0.515 -0.8572 0.8572 0.515 -23.7532 735.6929)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="10.998"/>
                                    <rect class="silla" id="silla164" x="669.224" y="404.728" transform="matrix(0.5149 -0.8572 0.8572 0.5149 -24.7941 777.6401)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11" height="12"/>
                                    <rect class="silla" id="silla165" x="624.554" y="397.052" transform="matrix(0.5149 -0.8572 0.8572 0.5149 -39.4639 735.3618)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="11"/>
                                    <rect class="silla" id="silla166" x="660.983" y="418.442" transform="matrix(0.515 -0.8572 0.8572 0.515 -40.6008 777.1215)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="12"/>
                                    <rect class="silla" id="silla167" x="617.072" y="410.339" transform="matrix(0.515 -0.8572 0.8572 0.515 -54.7427 734.9285)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="9.999" height="11.001"/>
                                    <rect class="silla" id="silla168" x="653.501" y="431.729" transform="matrix(0.5151 -0.8572 0.8572 0.5151 -55.8663 776.7123)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="silla169" x="626.489" y="433.499" transform="matrix(0.5151 -0.8571 0.8571 0.5151 -70.0687 754.1389)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="9.999" height="10.998"/>
                                    <text transform="matrix(1 0 0 1 646.7822 409.4102)" font-family="'MyriadPro-Regular'" font-size="12">16</text>
   
                                </a>
                                <a xlink:href="" xlink:title="Mesa 17" class="dropdown-item" href="<?= base_url ('index.php/evento/evento1?mesa=17') ?>" >
                                    <rect id="mesa17" x="675.061" y="429.926" transform="matrix(0.515 -0.8572 0.8572 0.515 -35.7067 815.7397)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="55.999" height="19.001"/>
                                    <rect class="silla" id="silla170" x="718.147" y="400.496" transform="matrix(0.5149 -0.8572 0.8572 0.5149 2.7387 816.8323)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10" height="11.001"/>
                                    <rect class="silla" id="silla171" x="692.764" y="403.911" transform="matrix(0.5151 -0.8571 0.8571 0.5151 -12.5717 796.5981)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="9.999" height="10.998"/>
                                    <rect class="silla" id="silla172" x="729.192" y="425.299" transform="matrix(0.515 -0.8572 0.8572 0.515 -13.6278 838.5115)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10.001" height="12"/>
                                    <rect class="silla" id="silla173" x="684.794" y="416.339" transform="matrix(0.515 -0.8572 0.8572 0.515 -26.8218 796.2689)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="10.998"/>
                                    <rect class="silla" id="silla174" x="721.224" y="437.728" transform="matrix(0.5149 -0.8572 0.8572 0.5149 -27.8586 838.2246)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11" height="12"/>
                                    <rect class="silla" id="silla175" x="676.554" y="430.052" transform="matrix(0.5149 -0.8572 0.8572 0.5149 -42.5292 795.9445)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="11"/>
                                    <rect class="silla" id="silla176" x="712.983" y="451.442" transform="matrix(0.515 -0.8572 0.8572 0.515 -43.6695 837.6976)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="12"/>
                                    <rect class="silla" id="silla177" x="669.072" y="443.339" transform="matrix(0.515 -0.8572 0.8572 0.515 -57.8094 795.5084)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="9.999" height="11.001"/>
                                    <rect class="silla" id="silla178" x="705.501" y="464.729" transform="matrix(0.5151 -0.8572 0.8572 0.5151 -58.9354 837.2876)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="silla179" x="678.489" y="466.499" transform="matrix(0.5151 -0.8571 0.8571 0.5151 -73.1392 814.7114)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="9.999" height="10.998"/>
                                    <text transform="matrix(1 0 0 1 697.4131 444.1758)" font-family="'MyriadPro-Regular'" font-size="12">17</text>
   
                                </a>
                                <a xlink:href="" xlink:title="Mesa 18" class="dropdown-item" href="<?= base_url ('index.php/evento/evento1?mesa=18') ?>" >
                                    <rect  id="mesa18" x="727.061" y="461.926" transform="matrix(0.515 -0.8572 0.8572 0.515 -37.9182 875.8308)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="55.999" height="19.001"/>
                                    <rect class="silla" id="silla180" x="770.147" y="432.496" transform="matrix(0.5149 -0.8572 0.8572 0.5149 0.5306 876.9299)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10" height="11.001"/>
                                    <rect class="silla" id="silla181" x="744.764" y="435.911" transform="matrix(0.5151 -0.8571 0.8571 0.5151 -14.785 856.6858)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="9.999" height="10.998"/>
                                    <polyline class="silla" id="silla182" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" points="793.91,462.104 788.76,470.676 
                                        778.475,464.494 783.625,455.924 793.91,462.104 "/>
                                    <rect class="silla" id="silla183" x="736.794" y="448.339" transform="matrix(0.515 -0.8572 0.8572 0.515 -29.0334 856.36)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="10.998"/>
                                    <rect class="silla" id="silla184" x="773.224" y="469.728" transform="matrix(0.5149 -0.8572 0.8572 0.5149 -30.0658 898.324)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11" height="12"/>
                                    <rect class="silla" id="silla185" x="728.554" y="462.052" transform="matrix(0.5149 -0.8572 0.8572 0.5149 -44.7372 856.0422)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="11"/>
                                    <rect class="silla" id="silla186" x="764.983" y="483.442" transform="matrix(0.515 -0.8572 0.8572 0.515 -45.881 897.7887)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="12"/>
                                    <rect class="silla" id="silla187" x="722.072" y="475.339" transform="matrix(0.515 -0.8572 0.8572 0.515 -59.5339 856.4606)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="9.999" height="11.001"/>
                                    <rect class="silla" id="silla188" x="757.501" y="496.729" transform="matrix(0.5151 -0.8572 0.8572 0.5151 -61.1473 897.3779)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="silla189" x="730.489" y="498.499" transform="matrix(0.5151 -0.8571 0.8571 0.5151 -75.3525 874.7991)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="9.999" height="10.998"/>
                                    <text transform="matrix(1 0 0 1 751.7461 473.5098)" font-family="'MyriadPro-Regular'" font-size="12">18</text>
   
                                </a>
                                <a xlink:href="" xlink:title="Mesa 19" class="dropdown-item" href="<?= base_url ('index.php/evento/evento1?mesa=19') ?>" >
                                    <rect  id="mesa19" x="461.061" y="419.926" transform="matrix(0.515 -0.8572 0.8572 0.515 -130.9155 627.4572)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="55.999" height="19.001"/>
                                    <rect class="silla" id="silla190" x="504.147" y="390.496" transform="matrix(0.5149 -0.8572 0.8572 0.5149 -92.4917 628.5354)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10" height="11.001"/>
                                    <rect class="silla" id="silla191" x="478.764" y="393.911" transform="matrix(0.5151 -0.8571 0.8571 0.5151 -107.7692 608.3232)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="9.999" height="10.998"/>
                                    <rect class="silla" id="silla192" x="515.192" y="415.299" transform="matrix(0.515 -0.8572 0.8572 0.515 -108.8433 650.2245)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10.001" height="12"/>
                                    <rect class="silla" id="silla193" x="470.794" y="406.339" transform="matrix(0.515 -0.8572 0.8572 0.515 -122.0308 607.9863)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="10.998"/>
                                    <rect class="silla" id="silla194" x="507.224" y="427.728" transform="matrix(0.5149 -0.8572 0.8572 0.5149 -123.0947 649.924)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11" height="12"/>
                                    <rect class="silla" id="silla195" x="462.554" y="420.052" transform="matrix(0.5149 -0.8572 0.8572 0.5149 -137.7598 607.6475)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="11"/>
                                    <rect class="silla" id="silla196" x="498.983" y="441.442" transform="matrix(0.515 -0.8572 0.8572 0.515 -138.8785 649.415)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="12"/>
                                    <rect class="silla" id="silla197" x="455.072" y="433.339" transform="matrix(0.515 -0.8572 0.8572 0.515 -153.0308 607.2175)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="9.999" height="11.001"/>
                                    <rect class="silla" id="silla198" x="491.501" y="454.729" transform="matrix(0.5151 -0.8572 0.8572 0.5151 -154.1418 649.0066)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="silla199" x="464.489" y="456.499" transform="matrix(0.5151 -0.8571 0.8571 0.5151 -168.3367 626.4364)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="9.999" height="10.998"/>
                                    <text transform="matrix(1 0 0 1 483.4541 432.541)" font-family="'MyriadPro-Regular'" font-size="12">19</text>
   
                                </a>
                                <a xlink:href="" xlink:title="Mesa 20" class="dropdown-item" href="<?= base_url ('index.php/evento/evento1?mesa=20') ?>" >
                                    <rect id="mesa20" x="514.061" y="451.926" transform="matrix(0.515 -0.8572 0.8572 0.515 -132.6421 688.4055)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="55.999" height="19.001"/>
                                    <rect class="silla" id="silla200" x="557.147" y="422.496" transform="matrix(0.5149 -0.8572 0.8572 0.5149 -94.2148 689.4902)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10" height="11.001"/>
                                    <rect class="silla" id="silla201" x="531.764" y="425.911" transform="matrix(0.5151 -0.8571 0.8571 0.5151 -109.4976 669.2679)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="9.999" height="10.998"/>
                                    <rect class="silla" id="silla202" x="568.192" y="447.299" transform="matrix(0.515 -0.8572 0.8572 0.515 -110.5688 711.1748)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10.001" height="12"/>
                                    <rect class="silla" id="silla203" x="523.794" y="438.339" transform="matrix(0.515 -0.8572 0.8572 0.515 -123.7574 668.9346)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="10.998"/>
                                    <rect class="silla" id="silla204" x="560.224" y="459.728" transform="matrix(0.5149 -0.8572 0.8572 0.5149 -124.8168 710.8806)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11" height="12"/>
                                    <rect class="silla" id="silla205" x="515.554" y="452.052" transform="matrix(0.5149 -0.8572 0.8572 0.5149 -139.4829 668.6024)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="11"/>
                                    <rect class="silla" id="silla206" x="551.983" y="473.442" transform="matrix(0.515 -0.8572 0.8572 0.515 -140.605 710.3633)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="12"/>
                                    <rect class="silla" id="silla207" x="508.072" y="465.339" transform="matrix(0.515 -0.8572 0.8572 0.515 -154.7554 668.1696)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="9.999" height="11.001"/>
                                    <rect class="silla" id="silla208" x="544.501" y="486.729" transform="matrix(0.5151 -0.8572 0.8572 0.5151 -155.8688 709.9541)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="silla209" x="517.489" y="488.499" transform="matrix(0.5151 -0.8571 0.8571 0.5151 -170.0651 687.3812)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="9.999" height="10.998"/>
                                    <text  transform="matrix(1 0 0 1 536.4463 465.0586)" font-family="'MyriadPro-Regular'" font-size="12">20</text>
   
                                </a>
                                <a xlink:href="" xlink:title="Mesa 21" class="dropdown-item" href="<?= base_url ('index.php/evento/evento1?mesa=21') ?>" >
                                    <rect  id="mesa21" x="570.061" y="483.926" transform="matrix(0.515 -0.8572 0.8572 0.515 -132.9138 751.9252)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="55.999" height="19.001"/>
                                    <rect class="silla" id="silla210" x="613.147" y="454.496" transform="matrix(0.5149 -0.8572 0.8572 0.5149 -94.4827 753.0167)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10" height="11.001"/>
                                    <rect class="silla" id="silla211" x="587.764" y="457.911" transform="matrix(0.5151 -0.8571 0.8571 0.5151 -109.7713 732.7841)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="9.999" height="10.998"/>
                                    <rect class="silla" id="silla212" x="624.192" y="479.299" transform="matrix(0.515 -0.8572 0.8572 0.515 -110.8394 774.6966)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10.001" height="12"/>
                                    <rect class="silla" id="silla213" x="579.794" y="470.339" transform="matrix(0.515 -0.8572 0.8572 0.515 -124.0291 732.4543)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="10.998"/>
                                    <rect class="silla" id="silla214" x="616.224" y="491.728" transform="matrix(0.5149 -0.8572 0.8572 0.5149 -125.0837 774.4089)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11" height="12"/>
                                    <rect class="silla" id="silla215" x="571.554" y="484.052" transform="matrix(0.5149 -0.8572 0.8572 0.5149 -139.7507 732.129)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="11"/>
                                    <rect class="silla" id="silla216" x="607.983" y="505.442" transform="matrix(0.515 -0.8572 0.8572 0.515 -140.8767 773.8831)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="12"/>
                                    <rect class="silla" id="silla217" x="564.072" y="497.339" transform="matrix(0.515 -0.8572 0.8572 0.515 -155.0249 731.6934)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="9.999" height="11.001"/>
                                    <rect class="silla" id="silla218" x="600.501" y="518.729" transform="matrix(0.5151 -0.8572 0.8572 0.5151 -156.141 773.4731)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="silla219" x="573.489" y="520.499" transform="matrix(0.5151 -0.8571 0.8571 0.5151 -170.3388 750.8973)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="9.999" height="10.998"/>
                                    <text transform="matrix(1 0 0 1 593.1396 495.625)" font-family="'MyriadPro-Regular'" font-size="12">21</text>
    
                                </a>
                                <a xlink:href="" xlink:title="Mesa 22" class="dropdown-item" href="<?= base_url ('index.php/evento/evento1?mesa=22') ?>" >
                                    <rect id="mesa22" x="623.061" y="515.926" transform="matrix(0.515 -0.8572 0.8572 0.515 -134.6404 812.8734)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="55.999" height="19.001"/>
                                    <rect class="silla" id="silla220" x="666.147" y="486.496" transform="matrix(0.5149 -0.8572 0.8572 0.5149 -96.2057 813.9716)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10" height="11.001"/>
                                    <rect class="silla" id="silla221" x="640.764" y="489.911" transform="matrix(0.5151 -0.8571 0.8571 0.5151 -111.4998 793.7289)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="9.999" height="10.998"/>
                                    <rect class="silla" id="silla222" x="677.192" y="511.299" transform="matrix(0.515 -0.8572 0.8572 0.515 -112.5649 835.6469)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10.001" height="12"/>
                                    <rect class="silla" id="silla223" x="632.794" y="502.339" transform="matrix(0.515 -0.8572 0.8572 0.515 -125.7557 793.4026)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="10.998"/>
                                    <rect class="silla" id="silla224" x="669.224" y="523.728" transform="matrix(0.5149 -0.8572 0.8572 0.5149 -126.8058 835.3655)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11" height="12"/>
                                    <rect class="silla" id="silla225" x="624.554" y="516.052" transform="matrix(0.5149 -0.8572 0.8572 0.5149 -141.4738 793.0839)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="11"/>
                                    <rect class="silla" id="silla226" x="660.983" y="537.442" transform="matrix(0.515 -0.8572 0.8572 0.515 -142.6033 834.8313)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="12"/>
                                    <rect class="silla" id="silla227" x="617.072" y="529.339" transform="matrix(0.515 -0.8572 0.8572 0.515 -156.7495 792.6454)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="9.999" height="11.001"/>
                                    <rect class="silla" id="silla228" x="653.501" y="550.729" transform="matrix(0.5151 -0.8572 0.8572 0.5151 -157.8679 834.4207)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="silla229" x="626.489" y="552.499" transform="matrix(0.5151 -0.8571 0.8571 0.5151 -172.0673 811.8421)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="9.999" height="10.998"/>
                                    <text  transform="matrix(1 0 0 1 645.7822 528.7207)" font-family="'MyriadPro-Regular'" font-size="12">22</text>
   
                                </a>
                                <a xlink:href="" xlink:title="Mesa 23" class="dropdown-item" href="<?= base_url ('index.php/evento/evento1?mesa=23') ?>" >
                                    <rect id="mesa23" x="466.061" y="538.926" transform="matrix(0.515 -0.8572 0.8572 0.515 -230.4932 689.4528)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="55.999" height="19.001"/>
                                    <rect  class="silla" id="silla230" x="507.147" y="510.496" transform="matrix(0.5149 -0.8572 0.8572 0.5149 -193.9036 689.3141)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10" height="11.001"/>
                                    <rect  class="silla" id="silla231" x="481.764" y="513.911" transform="matrix(0.5151 -0.8571 0.8571 0.5151 -209.1702 669.0827)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="9.999" height="10.998"/>
                                    <rect  class="silla" id="silla232" x="518.192" y="535.299" transform="matrix(0.515 -0.8572 0.8572 0.515 -210.2502 710.9945)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10.001" height="12"/>
                                    <rect  class="silla" id="silla233" x="473.794" y="526.339" transform="matrix(0.515 -0.8572 0.8572 0.515 -223.4356 668.7525)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="10.998"/>
                                    <rect  class="silla" id="silla234" x="510.224" y="547.728" transform="matrix(0.5149 -0.8572 0.8572 0.5149 -224.5084 710.7061)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11" height="12"/>
                                    <rect  class="silla" id="silla235" x="465.554" y="540.052" transform="matrix(0.5149 -0.8572 0.8572 0.5149 -239.1718 668.4264)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="11"/>
                                    <rect  class="silla" id="silla236" x="501.983" y="561.442" transform="matrix(0.515 -0.8572 0.8572 0.515 -240.2833 710.1812)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="12"/>
                                    <rect  class="silla" id="silla237" x="458.072" y="553.339" transform="matrix(0.515 -0.8572 0.8572 0.515 -254.4398 667.991)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="9.999" height="11.001"/>
                                    <rect  class="silla" id="silla238" x="494.501" y="574.729" transform="matrix(0.5151 -0.8572 0.8572 0.5151 -255.5458 709.7714)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect  class="silla" id="silla239" x="467.489" y="576.499" transform="matrix(0.5151 -0.8571 0.8571 0.5151 -269.7377 687.1959)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="9.999" height="10.998"/>
                                    <text   transform="matrix(1 0 0 1 486.0791 553.8418)" font-family="'MyriadPro-Regular'" font-size="12">23</text>
   
                                </a>
                                <a xlink:href="" xlink:title="Mesa 24" class="dropdown-item" href="<?= base_url ('index.php/evento/evento1?mesa=24') ?>" >
                                    <rect id="mesa24" x="518.061" y="570.926" transform="matrix(0.515 -0.8572 0.8572 0.515 -232.7047 749.5438)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="55.999" height="19.001"/>
                                    <rect class="silla" id="silla240" x="561.147" y="541.496" transform="matrix(0.5149 -0.8572 0.8572 0.5149 -194.2844 750.6412)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10" height="11.001"/>
                                    <rect class="silla" id="silla241" x="535.764" y="544.911" transform="matrix(0.5151 -0.8571 0.8571 0.5151 -209.5566 730.3997)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="9.999" height="10.998"/>
                                    <rect class="silla" id="silla242" x="572.192" y="566.299" transform="matrix(0.515 -0.8572 0.8572 0.515 -210.6336 772.317)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10.001" height="12"/>
                                    <rect class="silla" id="silla243" x="527.794" y="557.339" transform="matrix(0.515 -0.8572 0.8572 0.515 -223.8201 730.073)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="10.998"/>
                                    <rect class="silla" id="silla244" x="564.224" y="578.728" transform="matrix(0.5149 -0.8572 0.8572 0.5149 -224.8883 772.0348)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11" height="12"/>
                                    <rect class="silla" id="silla245" x="519.554" y="571.052" transform="matrix(0.5149 -0.8572 0.8572 0.5149 -239.5526 729.7535)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="11"/>
                                    <rect class="silla" id="silla246" x="555.983" y="592.442" transform="matrix(0.515 -0.8572 0.8572 0.515 -240.6677 771.5017)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="12"/>
                                    <rect class="silla" id="silla247" x="512.072" y="584.339" transform="matrix(0.515 -0.8572 0.8572 0.515 -254.8221 729.3153)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="9.999" height="11.001"/>
                                    <rect class="silla" id="silla248" x="548.501" y="605.729" transform="matrix(0.5151 -0.8572 0.8572 0.5151 -255.9307 771.0911)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="silla249" x="521.489" y="607.499" transform="matrix(0.5151 -0.8571 0.8571 0.5151 -270.1241 748.5129)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="9.999" height="10.998"/>
                                    <text  transform="matrix(1 0 0 1 542.0527 583.4102)" font-family="'MyriadPro-Regular'" font-size="12">24</text>
   
                                </a>
                                <a xlink:href="" xlink:title="Mesa 25" class="dropdown-item" href="<?= base_url ('index.php/evento/evento1?mesa=25') ?>" >
                                    <rect id="mesa25" x="571.061" y="602.926" transform="matrix(0.515 -0.8572 0.8572 0.515 -234.4313 810.4921)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="55.999" height="19.001"/>
                                    <rect class="silla"id="silla250" x="614.147" y="573.496" transform="matrix(0.5149 -0.8572 0.8572 0.5149 -196.0075 811.596)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10" height="11.001"/>
                                    <rect class="silla"id="silla251" x="588.764" y="576.911" transform="matrix(0.5151 -0.8571 0.8571 0.5151 -211.285 791.3445)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="9.999" height="10.998"/>
                                    <rect class="silla"id="silla252" x="625.192" y="598.299" transform="matrix(0.515 -0.8572 0.8572 0.515 -212.3591 833.2673)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10.001" height="12"/>
                                    <rect class="silla"id="silla253" x="580.794" y="589.339" transform="matrix(0.515 -0.8572 0.8572 0.515 -225.5466 791.0212)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="10.998"/>
                                    <rect class="silla"id="silla254" x="617.224" y="610.728" transform="matrix(0.5149 -0.8572 0.8572 0.5149 -226.6104 832.9914)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11" height="12"/>
                                    <rect class="silla"id="silla255" x="572.554" y="603.052" transform="matrix(0.5149 -0.8572 0.8572 0.5149 -241.2756 790.7084)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="11"/>
                                    <rect class="silla"id="silla256" x="608.983" y="624.442" transform="matrix(0.515 -0.8572 0.8572 0.515 -242.3943 832.45)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="11.001" height="12"/>
                                    <rect class="silla"id="silla257" x="565.072" y="616.339" transform="matrix(0.515 -0.8572 0.8572 0.515 -256.5466 790.2675)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="9.999" height="11.001"/>
                                    <rect class="silla"id="silla258" x="601.501" y="637.729" transform="matrix(0.5151 -0.8572 0.8572 0.5151 -257.6577 832.0386)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla"id="silla259" x="574.489" y="639.499" transform="matrix(0.5151 -0.8571 0.8571 0.5151 -271.8525 809.4577)" fill="#FFFFFF" stroke="#004AEC" stroke-miterlimit="10" width="9.999" height="10.998"/>
                                    <text transform="matrix(1 0 0 1 595.0791 615.8418)" font-family="'MyriadPro-Regular'" font-size="12">25</text>
    
                                </a>
                                <a xlink:href="" xlink:title="Mesa 26" class="dropdown-item" href="<?= base_url ('index.php/evento/evento1?mesa=26') ?>" >
                                    <rect id="mesa26" x="277.5" y="20.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="56" height="19"/>
                                    <rect class="silla" id="silla260" x="339.5" y="24.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="10" height="11"/>
                                    <rect class="silla" id="silla261" x="323.5" y="4.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="10" height="11"/>
                                    <rect class="silla" id="silla262" x="323.5" y="46.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="silla263" x="308.5" y="4.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="11" height="11"/>
                                    <rect class="silla" id="silla264" x="308.5" y="46.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="11" height="12"/>
                                    <rect class="silla" id="silla265" x="292.5" y="4.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="11" height="11"/>
                                    <rect class="silla" id="silla266" x="292.5" y="46.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="11" height="12"/>
                                    <rect class="silla" id="silla267" x="277.5" y="4.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="10" height="11"/>
                                    <rect class="silla" id="silla268" x="277.5" y="46.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="silla269" x="262.5" y="24.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="10" height="11"/>
                                    <text transform="matrix(1 0 0 1 300 32.7754)" font-family="'MyriadPro-Regular'" font-size="12">26</text>
   
                                </a>
                                <a xlink:href="" xlink:title="Mesa 27" class="dropdown-item" href="<?= base_url ('index.php/evento/evento1?mesa=27') ?>" >
                                    <rect id="mesa27" x="277.5" y="92.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="56" height="19"/>
                                    <rect class="silla" id="silla270" x="339.5" y="96.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="10" height="11"/>
                                    <rect class="silla" id="silla271" x="323.5" y="76.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="10" height="11"/>
                                    <rect class="silla" id="silla272" x="323.5" y="118.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="silla274" x="308.5" y="118.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="11" height="12"/>
                                    <rect class="silla" id="silla275" x="292.5" y="76.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="11" height="11"/>
                                    <rect class="silla" id="silla276" x="292.5" y="118.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="11" height="12"/>
                                    <rect class="silla" id="silla277" x="277.5" y="76.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="10" height="11"/>
                                    <rect class="silla" id="silla273" x="308.5" y="76.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="11" height="11"/>
                                    <rect class="silla" id="silla278" x="277.5" y="118.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="silla279" x="262.5" y="96.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="10" height="11"/>
                                    <text transform="matrix(1 0 0 1 299.5186 106.0835)" font-family="'MyriadPro-Regular'" font-size="12">27</text>
    
                                </a>
                                <a xlink:href="" xlink:title="Mesa 28" class="dropdown-item" href="<?= base_url ('index.php/evento/evento1?mesa=28') ?>" >
                                    <rect id="mesa28" x="277.5" y="163.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="56" height="19"/>
                                    
                                    <rect class="silla" id="silla280" x="339.5" y="167.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="10" height="11"/>
                                    <rect class="silla" id="silla281" x="323.5" y="147.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="10" height="11"/>
                                    <rect class="silla" id="silla282" x="323.5" y="189.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="silla283" x="308.5" y="147.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="11" height="11"/>
                                    <rect class="silla" id="silla284" x="308.5" y="189.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="11" height="12"/>
                                    <rect class="silla" id="silla285" x="292.5" y="147.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="11" height="11"/>
                                    <rect class="silla" id="silla286" x="292.5" y="189.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="11" height="12"/>
                                    <rect class="silla" id="silla287" x="277.5" y="147.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="10" height="11"/>

                                    <rect class="silla" id="silla288" x="277.5" y="189.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="10" height="12"/>
                                    <!-- <rect class="silla" id="silla282" x="323.5" y="189.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="10" height="12"/> -->
                                    <rect class="silla" id="silla289" x="262.5" y="167.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="10" height="11"/>
                                    <text transform="matrix(1 0 0 1 298.5186 175.7285)" font-family="'MyriadPro-Regular'" font-size="12">28</text>
    
                                </a>
                                <a xlink:href="" xlink:title="Mesa 29" class="dropdown-item" href="<?= base_url ('index.php/evento/evento1?mesa=29') ?>" >
                                    <rect id="mesa29" x="277.5" y="302.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="56" height="19"/>
                                    <rect class="silla" id="silla290" x="339.5" y="306.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="10" height="11"/>
                                    <rect class="silla" id="silla291" x="323.5" y="286.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="10" height="11"/>
                                    <rect class="silla" id="silla292" x="323.5" y="328.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="silla293" x="308.5" y="286.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="11" height="11"/>
                                    <rect class="silla" id="silla294" x="308.5" y="328.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="11" height="12"/>
                                    <rect class="silla" id="silla295" x="292.5" y="286.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="11" height="11"/>
                                    <rect class="silla" id="silla296" x="292.5" y="328.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="11" height="12"/>
                                    <rect class="silla" id="silla297" x="277.5" y="286.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="10" height="11"/>
                                    <rect class="silla" id="silla298" x="277.5" y="328.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="silla299" x="262.5" y="306.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="10" height="11"/>
                                    <text transform="matrix(1 0 0 1 298 315.877)" font-family="'MyriadPro-Regular'" font-size="12">29</text>
    
                                </a>
                                <a xlink:href="" xlink:title="Mesa 30" class="dropdown-item" href="<?= base_url ('index.php/evento/evento1?mesa=30') ?>" >
                                    <rect id="mesa30" x="277.5" y="366.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="56" height="19"/>
                                    <rect class="silla" id="silla300" x="339.5" y="370.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="10" height="11"/>
                                    <rect class="silla" id="silla301" x="323.5" y="350.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="10" height="11"/>
                                    <rect class="silla" id="silla302" x="323.5" y="392.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="silla303" x="308.5" y="350.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="11" height="11"/>
                                    <rect class="silla" id="silla304" x="308.5" y="392.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="11" height="12"/>
                                    <rect class="silla" id="silla305" x="292.5" y="350.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="11" height="11"/>
                                    <rect class="silla" id="silla306" x="292.5" y="392.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="11" height="12"/>
                                    <rect class="silla" id="silla307" x="277.5" y="350.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="10" height="11"/>
                                    <rect class="silla" id="silla308" x="277.5" y="392.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="silla309" x="262.5" y="370.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="10" height="11"/>
                                    <text transform="matrix(1 0 0 1 298.5186 380.0005)" font-family="'MyriadPro-Regular'" font-size="12">30</text>
    
                                </a>
                                <a xlink:href="" xlink:title="Mesa 31" class="dropdown-item" href="<?= base_url ('index.php/evento/evento1?mesa=31') ?>" >
                                    <rect id="mesa31" x="277.5" y="427.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="56" height="19"/>
                                    <rect class="silla" id="silla310" x="339.5" y="431.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="10" height="11"/>
                                    <rect class="silla" id="silla311" x="323.5" y="411.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="10" height="11"/>
                                    <rect class="silla" id="silla312" x="323.5" y="453.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="silla313" x="308.5" y="411.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="11" height="11"/>
                                    <rect class="silla" id="silla314" x="308.5" y="452.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="11" height="12"/>
                                    <rect class="silla" id="silla315" x="292.5" y="411.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="11" height="11"/>
                                    <rect class="silla" id="silla316" x="292.5" y="453.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="11" height="12"/>
                                    <rect class="silla" id="silla317" x="277.5" y="411.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="10" height="11"/>
                                    <rect class="silla" id="silla318" x="277.5" y="453.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="silla319" x="262.5" y="431.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="10" height="11"/>
                                    <text transform="matrix(1 0 0 1 299.5 439.6367)" font-family="'MyriadPro-Regular'" font-size="12">31</text>
   
                                </a>
                                <a xlink:href="" xlink:title="Mesa 32" class="dropdown-item" href="<?= base_url ('index.php/evento/evento1?mesa=32') ?>" >
                                    <rect id="mesa32" x="280.5" y="493.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="56" height="19"/>
                                    <rect class="silla" id="silla320" x="339.5" y="497.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="10" height="11"/>
                                    <rect class="silla" id="silla321" x="323.5" y="477.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="10" height="11"/>
                                    <rect class="silla" id="silla322" x="323.5" y="519.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="silla323" x="308.5" y="477.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="11" height="11"/>
                                    <rect class="silla" id="silla324" x="308.5" y="519.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="11" height="12"/>
                                    <rect class="silla" id="silla325" x="292.5" y="477.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="11" height="11"/>
                                    <rect class="silla" id="silla326" x="292.5" y="519.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="11" height="12"/>
                                    <rect class="silla" id="silla327" x="277.5" y="477.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="10" height="11"/>
                                    <rect class="silla" id="silla328" x="277.5" y="519.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="silla329" x="262.5" y="497.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="10" height="11"/>
                                    <text transform="matrix(1 0 0 1 299.5 506.5313)" font-family="'MyriadPro-Regular'" font-size="12">32</text>
    
                                </a>
                                <a xlink:href="" xlink:title="Mesa 33" class="dropdown-item" href="<?= base_url ('index.php/evento/evento1?mesa=33') ?>" >
                                    <rect id="mesa33" x="277.5" y="559.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="56" height="19"/>
                                    <rect class="silla" id="silla330" x="339.5" y="563.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="10" height="11"/>
                                    <rect class="silla" id="silla331" x="323.5" y="543.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="10" height="11"/>
                                    <rect class="silla" id="silla332" x="323.5" y="585.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="silla333" x="308.5" y="543.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="11" height="11"/>
                                    <rect class="silla" id="silla334" x="308.5" y="585.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="11" height="12"/>
                                    <rect class="silla" id="silla335" x="292.5" y="543.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="11" height="11"/>
                                    <rect class="silla" id="silla336" x="292.5" y="585.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="11" height="12"/>
                                    <rect class="silla" id="silla337" x="277.5" y="543.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="10" height="11"/>
                                    <rect class="silla" id="silla338" x="277.5" y="585.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="silla339" x="262.5" y="563.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="10" height="11"/>
                                    <text transform="matrix(1 0 0 1 298.1855 573.084)" font-family="'MyriadPro-Regular'" font-size="12">33</text>
   
                                </a>
                                <a xlink:href="" xlink:title="Mesa 34" class="dropdown-item" href="<?= base_url ('index.php/evento/evento1?mesa=34') ?>" >
                                    <rect id="mesa34" x="277.5" y="622.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="56" height="19"/>
                                    <rect class="silla" id="silla340" x="339.5" y="626.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="10" height="11"/>
                                    <rect class="silla" id="silla341" x="323.5" y="606.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="10" height="11"/>
                                    <rect class="silla" id="silla342" x="323.5" y="648.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="silla343" x="308.5" y="606.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="11" height="11"/>
                                    <rect class="silla" id="silla344" x="308.5" y="648.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="11" height="12"/>
                                    <rect class="silla" id="silla345" x="292.5" y="606.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="11" height="11"/>
                                    <rect class="silla" id="silla346" x="292.5" y="648.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="11" height="12"/>
                                    <rect class="silla" id="silla347" x="277.5" y="606.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="10" height="11"/>
                                    <rect class="silla" id="silla348" x="277.5" y="648.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="silla349" x="262.5" y="626.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="10" height="11"/>
                                    <text transform="matrix(1 0 0 1 298.5186 635.416)" font-family="'MyriadPro-Regular'" font-size="12">34</text>
   
                                </a>
                                <a xlink:href="" xlink:title="Mesa 35" class="dropdown-item" href="<?= base_url ('index.php/evento/evento1?mesa=35') ?>" >
                                    <rect id="mesa35" x="277.5" y="688.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="56" height="19"/>
                                    <rect class="silla" id="silla350" x="339.5" y="692.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="10" height="11"/>
                                    <rect class="silla" id="silla351" x="323.5" y="672.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="10" height="11"/>
                                    <rect class="silla" id="silla352" x="323.5" y="714.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="silla353" x="308.5" y="672.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="11" height="11"/>
                                    <rect class="silla" id="silla354" x="308.5" y="714.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="11" height="12"/>
                                    <rect class="silla" id="silla355" x="292.5" y="672.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="11" height="11"/>
                                    <rect class="silla" id="silla356" x="292.5" y="714.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="11" height="12"/>
                                    <rect class="silla" id="silla357" x="277.5" y="672.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="10" height="11"/>
                                    <rect class="silla" id="silla358" x="277.5" y="714.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="silla359" x="262.5" y="692.5" fill="#FFFFFF" stroke="#FF2462" stroke-miterlimit="10" width="10" height="11"/>
                                    <text transform="matrix(1 0 0 1 298 701.5)" font-family="'MyriadPro-Regular'" font-size="12">35</text>
   
                                </a>
                                <a xlink:href="" xlink:title="Mesa 36" class="dropdown-item" href="<?= base_url ('index.php/evento/evento1?mesa=36') ?>" >
                                    <rect id="mesa36" x="173.5" y="20.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="56" height="19"/>
                                    <rect class="silla" id="silla360" x="235.5" y="24.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="10" height="11"/>
                                    <rect class="silla" id="silla361" x="219.5" y="4.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="10" height="11"/>
                                    <rect class="silla" id="silla362" x="219.5" y="46.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="silla363" x="204.5" y="4.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="11" height="11"/>
                                    <rect class="silla" id="silla364" x="204.5" y="46.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="11" height="12"/>
                                    <rect class="silla" id="silla365" x="188.5" y="4.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="11" height="11"/>
                                    <rect class="silla" id="silla366" x="188.5" y="46.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="11" height="12"/>
                                    <rect class="silla" id="silla367" x="173.5" y="4.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="10" height="11"/>
                                    <rect class="silla" id="silla368" x="173.5" y="46.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="silla369" x="158.5" y="24.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="10" height="11"/>
                                    <text transform="matrix(1 0 0 1 194 33.8389)" font-family="'MyriadPro-Regular'" font-size="12">36</text>
   
                                </a>
                                 <a xlink:href="" xlink:title="Mesa 37" class="dropdown-item" href="<?= base_url ('index.php/evento/evento1?mesa=37') ?>" > 
                                    <rect id="mesa37" x="173.5" y="92.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="56" height="19"/>
                                    <rect class="silla" id="silla370" x="235.5" y="96.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="10" height="11"/>
                                    <rect class="silla" id="silla371" x="219.5" y="76.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="10" height="11"/>
                                    <rect class="silla" id="silla372" x="219.5" y="118.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="silla373" x="204.5" y="76.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="11" height="11"/>
                                    <rect class="silla" id="silla374" x="204.5" y="118.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="11" height="12"/>
                                    <rect class="silla" id="silla375" x="188.5" y="76.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="11" height="11"/>
                                    <rect class="silla" id="silla376" x="188.5" y="118.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="11" height="12"/>
                                    <rect class="silla" id="silla377" x="173.5" y="76.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="10" height="11"/>
                                    <rect class="silla" id="silla378" x="173.5" y="118.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="silla379" x="158.5" y="96.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="10" height="11"/>
                                    <text transform="matrix(1 0 0 1 194.833 104.8789)" font-family="'MyriadPro-Regular'" font-size="12">37</text>
   
                                </a>
                                 <a xlink:href="" xlink:title="Mesa 38" class="dropdown-item" href="<?= base_url ('index.php/evento/evento1?mesa=38') ?>" >
                                    <rect id="mesa38" x="173.5" y="163.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="56" height="19"/>
                                    <rect class="silla" id="silla380" x="235.5" y="167.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="10" height="11"/>
                                    <rect class="silla" id="silla381" x="219.5" y="147.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="10" height="11"/>
                                    <rect class="silla" id="silla382" x="219.5" y="189.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="silla383" x="204.5" y="147.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="11" height="11"/>
                                    <rect class="silla" id="silla384" x="204.5" y="189.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="11" height="12"/>
                                    <rect class="silla" id="silla385" x="188.5" y="147.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="11" height="11"/>
                                    <rect class="silla" id="silla386" x="188.5" y="189.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="11" height="12"/>
                                    <rect class="silla" id="silla387" x="173.5" y="147.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="10" height="11"/>
                                    <rect class="silla" id="silla388" x="173.5" y="189.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="silla389" x="158.5" y="167.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="10" height="11"/>
                                    <text transform="matrix(1 0 0 1 194.666 176.833)" font-family="'MyriadPro-Regular'" font-size="12">38</text>
    
                                </a>
                                 <a xlink:href="" xlink:title="Mesa 39" class="dropdown-item" href="<?= base_url ('index.php/evento/evento1?mesa=39') ?>" >
                                    <rect id="mesa39" x="173.5" y="302.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="56" height="19"/>
                                    <rect class="silla" id="silla390" x="235.5" y="306.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="10" height="11"/>
                                    <rect class="silla" id="silla391" x="219.5" y="286.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="10" height="11"/>
                                    <rect class="silla" id="silla392" x="219.5" y="328.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="silla393" x="204.5" y="286.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="11" height="11"/>
                                    <rect class="silla" id="silla394" x="204.5" y="328.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="11" height="12"/>
                                    <rect class="silla" id="silla395" x="188.5" y="286.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="11" height="11"/>
                                    <rect class="silla" id="silla396" x="188.5" y="328.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="11" height="12"/>
                                    <rect class="silla" id="silla397" x="173.5" y="286.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="10" height="11"/>
                                    <rect class="silla" id="silla398" x="173.5" y="328.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="silla399" x="158.5" y="306.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="10" height="11"/>
                                    <text transform="matrix(1 0 0 1 194 315.5)" font-family="'MyriadPro-Regular'" font-size="12">39</text>
    
                                </a>
                                 <a xlink:href="" xlink:title="Mesa 40" class="dropdown-item" href="<?= base_url ('index.php/evento/evento1?mesa=40') ?>" >
                                    <rect id="mesa40" x="173.5" y="366.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="56" height="19"/>
                                    <rect class="silla" id="silla400" x="235.5" y="370.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="10" height="11"/>
                                    <rect class="silla" id="silla401" x="219.5" y="350.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="10" height="11"/>
                                    <rect class="silla" id="silla402" x="219.5" y="392.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="silla403" x="204.5" y="350.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="11" height="11"/>
                                    <rect class="silla" id="silla404" x="204.5" y="392.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="11" height="12"/>
                                    <rect class="silla" id="silla405" x="188.5" y="350.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="11" height="11"/>
                                    <rect class="silla" id="silla406" x="188.5" y="392.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="11" height="12"/>
                                    <rect class="silla" id="silla407" x="173.5" y="350.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="10" height="11"/>
                                    <rect class="silla" id="silla408" x="173.5" y="392.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="silla409" x="158.5" y="370.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="10" height="11"/>
                                    <text transform="matrix(1 0 0 1 194 380.2471)" font-family="'MyriadPro-Regular'" font-size="12">40</text>
   
                                </a>
                                 <a xlink:href="" xlink:title="Mesa 41" class="dropdown-item" href="<?= base_url ('index.php/evento/evento1?mesa=41') ?>" >
                                    <rect id="mesa41" x="173.5" y="427.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="56" height="19"/>
                                    <rect class="silla" id="silla410" x="235.5" y="431.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="10" height="11"/>
                                    <rect class="silla" id="silla411" x="219.5" y="411.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="10" height="11"/>
                                    <rect class="silla" id="silla412" x="219.5" y="453.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="silla413" x="204.5" y="411.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="11" height="11"/>
                                    <rect class="silla" id="silla414" x="204.5" y="453.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="11" height="12"/>
                                    <rect class="silla" id="silla415" x="188.5" y="411.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="11" height="11"/>
                                    <rect class="silla" id="silla416" x="188.5" y="453.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="11" height="12"/>
                                    <rect class="silla" id="silla417" x="173.5" y="411.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="10" height="11"/>
                                    <rect class="silla" id="silla418" x="173.5" y="453.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="silla419" x="158.5" y="431.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="10" height="11"/>
                                    <text transform="matrix(1 0 0 1 195 441.5332)" font-family="'MyriadPro-Regular'" font-size="12">41</text>
   
                                </a>
                                 <a xlink:href="" xlink:title="Mesa 42" class="dropdown-item" href="<?= base_url ('index.php/evento/evento1?mesa=42') ?>" >
                                    <rect id="mesa42" x="173.5" y="493.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="56" height="19"/>
                                    <rect class="silla" id="silla420" x="235.5" y="497.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="10" height="11"/>
                                    <rect class="silla" id="silla421" x="219.5" y="477.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="10" height="11"/>
                                    <rect class="silla" id="silla422" x="219.5" y="519.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="silla423" x="204.5" y="477.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="11" height="11"/>
                                    <rect class="silla" id="silla424" x="204.5" y="519.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="11" height="12"/>
                                    <rect class="silla" id="silla425" x="188.5" y="477.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="11" height="11"/>
                                    <rect class="silla" id="silla426" x="188.5" y="519.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="11" height="12"/>
                                    <rect class="silla" id="silla427" x="173.5" y="477.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="10" height="11"/>
                                    <rect class="silla" id="silla428" x="173.5" y="519.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="silla429" x="158.5" y="497.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="10" height="11"/>
                                    <text transform="matrix(1 0 0 1 195 505.998)" font-family="'MyriadPro-Regular'" font-size="12">42</text>
   
                                </a>
                                 <a xlink:href="" xlink:title="Mesa 43" class="dropdown-item" href="<?= base_url ('index.php/evento/evento1?mesa=43') ?>" >
                                    <rect id="mesa43" x="173.5" y="559.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="56" height="19"/>
                                    <rect class="silla" id="silla430" x="235.5" y="563.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="10" height="11"/>
                                    <rect class="silla" id="silla431" x="219.5" y="543.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="10" height="11"/>
                                    <rect class="silla" id="silla432" x="219.5" y="585.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="silla433" x="204.5" y="543.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="11" height="11"/>
                                    <rect class="silla" id="silla434" x="204.5" y="585.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="11" height="12"/>
                                    <rect class="silla" id="silla435" x="188.5" y="543.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="11" height="11"/>
                                    <rect class="silla" id="silla436" x="188.5" y="585.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="11" height="12"/>
                                    <rect class="silla" id="silla437" x="173.5" y="543.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="10" height="11"/>
                                    <rect class="silla" id="silla438" x="173.5" y="585.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="silla439" x="158.5" y="563.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="10" height="11"/>
                                    <text transform="matrix(1 0 0 1 195 573.8789)" font-family="'MyriadPro-Regular'" font-size="12">43</text>
    
                                </a>
                                 <a xlink:href="" xlink:title="Mesa 44" class="dropdown-item" href="<?= base_url ('index.php/evento/evento1?mesa=44') ?>" >
                                    <rect id="mesa44" x="173.5" y="622.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="56" height="19"/>
                                    <rect class="silla" id="silla440" x="235.5" y="626.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="10" height="11"/>
                                    <rect class="silla" id="silla441" x="219.5" y="606.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="10" height="11"/>
                                    <rect class="silla" id="silla443" x="204.5" y="606.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="11" height="11"/>
                                    <rect class="silla" id="silla442" x="219.5" y="648.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="silla444" x="204.5" y="648.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="11" height="12"/>
                                    <rect class="silla" id="silla445" x="188.5" y="606.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="11" height="11"/>
                                    <rect class="silla" id="silla446" x="188.5" y="648.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="11" height="12"/>
                                    <rect class="silla" id="silla447" x="173.5" y="606.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="10" height="11"/>
                                    <rect class="silla" id="silla448" x="173.5" y="648.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="silla449" x="158.5" y="626.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="10" height="11"/>
                                    <text transform="matrix(1 0 0 1 195.666 635.834)" font-family="'MyriadPro-Regular'" font-size="12">44</text>
   
                                </a>
                                 <a xlink:href="" xlink:title="Mesa 45" class="dropdown-item" href="<?= base_url ('index.php/evento/evento1?mesa=45') ?>" >
                                    <rect id="mesa45" x="173.5" y="688.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="56" height="19"/>
                                    <rect class="silla" id="silla450" x="235.5" y="692.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="10" height="11"/>
                                    <rect class="silla" id="silla451" x="219.5" y="672.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="10" height="11"/>
                                    <rect class="silla" id="silla452" x="219.5" y="714.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="silla453" x="204.5" y="672.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="11" height="11"/>
                                    <rect class="silla" id="silla454" x="204.5" y="714.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="11" height="12"/>
                                    <rect class="silla" id="silla455" x="188.5" y="672.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="11" height="11"/>
                                    <rect class="silla" id="silla456" x="188.5" y="714.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="11" height="12"/>
                                    <rect class="silla" id="silla457" x="173.5" y="672.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="10" height="11"/>
                                    <rect class="silla" id="silla458" x="173.5" y="714.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="silla459" x="158.5" y="692.5" fill="#FFFFFF" stroke="#00A320" stroke-miterlimit="10" width="10" height="11"/>
                                    <text transform="matrix(1 0 0 1 196.833 701.5)" font-family="'MyriadPro-Regular'" font-size="12">45</text>
    
                                </a>
                                    
                                 <a xlink:href="" xlink:title="General" class="dropdown-item" href="<?= base_url ('index.php/evento/evento1?mesa=46') ?>" >
                                    <rect class="silla" id="general241" x="130.5" y="720.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general232" x="130.5" y="701.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general223" x="130.5" y="682.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general214" x="130.5" y="666.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general205" x="130.5" y="648.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general196" x="130.5" y="631.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general187" x="130.5" y="613.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general178" x="130.5" y="593.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general169" x="130.5" y="576.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general160" x="130.5" y="558.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general153" x="130.5" y="539.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general146" x="130.5" y="520.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general139" x="130.5" y="501.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general132" x="130.5" y="485.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general125" x="130.5" y="467.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general118" x="130.5" y="450.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general111" x="130.5" y="432.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general104" x="130.5" y="412.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general97" x="130.5" y="395.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general90" x="130.5" y="377.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general36" x="130.5" y="176.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general32" x="130.5" y="157.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general28" x="130.5" y="138.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general24" x="130.5" y="122.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general20" x="130.5" y="104.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general16" x="130.5" y="87.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general12" x="130.5" y="69.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general8" x="130.5" y="49.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general4" x="130.5" y="32.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general0" x="130.5" y="14.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general85" x="130.5" y="358.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general80" x="130.5" y="339.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general75" x="130.5" y="320.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general70" x="130.5" y="304.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general65" x="130.5" y="286.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general60" x="130.5" y="269.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general55" x="130.5" y="251.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general50" x="130.5" y="231.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general45" x="130.5" y="214.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general40" x="130.5" y="196.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general242" x="115.5" y="720.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general233" x="115.5" y="701.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general224" x="115.5" y="682.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general215" x="115.5" y="666.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general206" x="115.5" y="648.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general197" x="115.5" y="631.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general188" x="115.5" y="613.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general179" x="115.5" y="593.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general170" x="115.5" y="576.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general161" x="115.5" y="558.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general154" x="115.5" y="539.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general147" x="115.5" y="520.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general140" x="115.5" y="501.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general133" x="115.5" y="485.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general126" x="115.5" y="467.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general119" x="115.5" y="450.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general112" x="115.5" y="432.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general105" x="115.5" y="412.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general98" x="115.5" y="395.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general91" x="115.5" y="377.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general37" x="115.5" y="176.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general33" x="115.5" y="157.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general29" x="115.5" y="138.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general25" x="115.5" y="122.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general21" x="115.5" y="104.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general17" x="115.5" y="87.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general13" x="115.5" y="69.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general9" x="115.5" y="49.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general5" x="115.5" y="32.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general1" x="115.5" y="14.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general86" x="115.5" y="358.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general81" x="115.5" y="339.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general76" x="115.5" y="320.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general71" x="115.5" y="304.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general66" x="115.5" y="286.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general61" x="115.5" y="269.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general56" x="115.5" y="251.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general51" x="115.5" y="231.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general46" x="115.5" y="214.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general41" x="115.5" y="196.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general243" x="99.5" y="720.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general234" x="99.5" y="701.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general225" x="99.5" y="682.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general216" x="99.5" y="666.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general207" x="99.5" y="648.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general198" x="99.5" y="631.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general189" x="99.5" y="613.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general180" x="99.5" y="593.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general171" x="99.5" y="576.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general162" x="99.5" y="558.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general155" x="99.5" y="539.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general148" x="99.5" y="520.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general141" x="99.5" y="501.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general134" x="99.5" y="485.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general127" x="99.5" y="467.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general120" x="99.5" y="450.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general113" x="99.5" y="432.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general106" x="99.5" y="412.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general99" x="99.5" y="395.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general92" x="99.5" y="377.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general38" x="99.5" y="176.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general34" x="99.5" y="157.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general30" x="99.5" y="138.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general26" x="99.5" y="122.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general22" x="99.5" y="104.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general18" x="99.5" y="87.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general14" x="99.5" y="69.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general10" x="99.5" y="49.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general6" x="99.5" y="32.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general2" x="99.5" y="14.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general87" x="99.5" y="358.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general82" x="99.5" y="339.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general77" x="99.5" y="320.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general72" x="99.5" y="304.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general67" x="99.5" y="286.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general62" x="99.5" y="269.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general57" x="99.5" y="251.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general52" x="99.5" y="231.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general47" x="99.5" y="214.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general42" x="99.5" y="196.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general244" x="84.5" y="720.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general235" x="84.5" y="701.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general226" x="84.5" y="682.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general217" x="84.5" y="666.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general208" x="84.5" y="648.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general199" x="84.5" y="631.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general190" x="84.5" y="613.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general181" x="84.5" y="593.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general172" x="84.5" y="576.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general163" x="84.5" y="558.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general156" x="84.5" y="539.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general149" x="84.5" y="520.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general142" x="84.5" y="501.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general135" x="84.5" y="485.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general128" x="84.5" y="467.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general121" x="84.5" y="450.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general114" x="84.5" y="432.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general107" x="84.5" y="412.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general100" x="84.5" y="395.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general93" x="84.5" y="377.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general39" x="84.5" y="176.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general35" x="84.5" y="157.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general31" x="84.5" y="138.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general27" x="84.5" y="122.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general23" x="84.5" y="104.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general19" x="84.5" y="87.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general15" x="84.5" y="69.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general11" x="84.5" y="49.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general7" x="84.5" y="32.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general3" x="84.5" y="14.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general88" x="84.5" y="358.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general83" x="84.5" y="339.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general78" x="84.5" y="320.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general73" x="84.5" y="304.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general68" x="84.5" y="286.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general63" x="84.5" y="269.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general58" x="84.5" y="251.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general53" x="84.5" y="231.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general48" x="84.5" y="214.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general43" x="84.5" y="196.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general245" x="68.5" y="720.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general236" x="68.5" y="701.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general227" x="68.5" y="682.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general218" x="68.5" y="666.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general209" x="68.5" y="648.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general200" x="68.5" y="631.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general191" x="68.5" y="613.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general182" x="68.5" y="593.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general173" x="68.5" y="576.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general164" x="68.5" y="558.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general157" x="68.5" y="539.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general150" x="68.5" y="520.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general143" x="68.5" y="501.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general136" x="68.5" y="485.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general129" x="68.5" y="467.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general122" x="68.5" y="450.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general115" x="68.5" y="432.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general108" x="68.5" y="412.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general101" x="68.5" y="395.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general94" x="68.5" y="377.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general89" x="68.5" y="358.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general84" x="68.5" y="339.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general79" x="68.5" y="320.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general74" x="68.5" y="304.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general69" x="68.5" y="286.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general64" x="68.5" y="269.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general59" x="68.5" y="251.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general54" x="68.5" y="231.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general49" x="68.5" y="214.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general44" x="68.5" y="196.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general246" x="53.5" y="720.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general237" x="53.5" y="701.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general228" x="53.5" y="682.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general219" x="53.5" y="666.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general210" x="53.5" y="648.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general201" x="53.5" y="631.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general192" x="53.5" y="613.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general183" x="53.5" y="593.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general174" x="53.5" y="576.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general165" x="53.5" y="558.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general247" x="37.5" y="720.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general238" x="37.5" y="701.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general229" x="37.5" y="682.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general220" x="37.5" y="666.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general211" x="37.5" y="648.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general202" x="37.5" y="631.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general193" x="37.5" y="613.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general184" x="37.5" y="593.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general175" x="37.5" y="576.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general166" x="37.5" y="558.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general158" x="53.5" y="539.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general151" x="53.5" y="520.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general144" x="53.5" y="501.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general137" x="53.5" y="485.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general130" x="53.5" y="467.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general123" x="53.5" y="450.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general116" x="53.5" y="432.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general109" x="53.5" y="412.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general102" x="53.5" y="395.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general95" x="53.5" y="377.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general159" x="37.5" y="539.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general152" x="37.5" y="520.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general145" x="37.5" y="501.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general138" x="37.5" y="485.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general131" x="37.5" y="467.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general124" x="37.5" y="450.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general117" x="37.5" y="432.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general110" x="37.5" y="412.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general103" x="37.5" y="395.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general96" x="37.5" y="377.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general248" x="22.5" y="720.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general239" x="22.5" y="701.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general230" x="22.5" y="682.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general221" x="22.5" y="666.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general212" x="22.5" y="648.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general203" x="22.5" y="631.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general194" x="22.5" y="613.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general185" x="22.5" y="593.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general176" x="22.5" y="576.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general167" x="22.5" y="558.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general249" x="6.5" y="720.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general240" x="6.5" y="701.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general231" x="6.5" y="682.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general222" x="6.5" y="666.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general213" x="6.5" y="648.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general204" x="6.5" y="631.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general195" x="6.5" y="613.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general186" x="6.5" y="593.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general177" x="6.5" y="576.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                    <rect class="silla" id="general168" x="6.5" y="558.5" fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" width="10" height="12"/>
                                </a>
                                    <line fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" x1="150.5" y1="0" x2="150.5" y2="760"/>
                                    <line fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" x1="252.5" y1="0" x2="252.5" y2="760"/>
                                    <line fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" x1="367.5" y1="5" x2="367.5" y2="760"/>
                                    <line fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" x1="620.625" y1="190.924" x2="669.146" y2="105.247"/>
                                    <line fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" x1="669.146" y1="105.247" x2="800" y2="182.5"/>
                                    <line fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" x1="800" y1="182.5" x2="793.91" y2="290.997"/>
                                    <line fill="#FFFFFF" stroke="#000000" stroke-miterlimit="10" x1="793.91" y1="291.425" x2="620.625" y2="190.924"/>
                                    <text transform="matrix(0.866 0.5 -0.5 0.866 663.8955 166.7656)" font-family="'TimesNewRomanPSMT'" font-size="24">ESCENARIO</text>
                                   
                                  
                                    <path d="M0,0"/>
                                    </svg>
<!-- asta aca -->

                                <!-- asta este punto perteence la imagen del mapa -->
                            </div>
                        </div>

                        <!-- Pie Chart -->
                        <div class="col-xl-3 col-lg-2">
                            <div class="card shadow mb-5">
                            <form action="<?php echo base_url();?>index.php/evento/formUser" method="GET">

                                <!-- Card Header - Dropdown -->
                                <div
                                    class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 class="m-0 font-weight-bold text-primary">Registro</h6>

                                </div>
                                <!-- Card Body -->


                                <div class="card-body">

                                    <!-- desde aca se pondra la posicion de las sillas -->

                                    <div class="form-group row">
                                        <div id="output" class="col-sm-5 mb-3 mb-sm-0">
                                            <label for="" class="m-0 font-weight-bold text-info">Mesa:
                                            <input type="text"  class="form-control form-control-user" id="numSilla" name="numSilla" requirem readonly
                                                placeholder="Mesa"
                                                value ="<?php 
                                                if ($mesa == 46) {
                                                   echo "general";
                                                }
                                                else {
                                                    echo $mesa;
                                                }
                                                ?>"
                                                > </label>                                               
                                        </div>
                                  
                                        <div class="form-group">
                                                 <label for="" class="m-0 font-weight-bold text-info">Cant. Sillas:
                                                <select class="form-control" name="silla" id="silla" class="form-control input-lg">
                                                    <option value="">Seleccionar cantidad</option>  
                                                                <?php
                                                                    foreach ($arrMesa as $id => $mesa)
                                                                    
                                                                        echo '<option values="',$id,'">',$mesa,'</option>';
                                                                    
                                                                ?>
                                                                                                              
                                                </select>
                                        </div>
                                        <div class="col-sm-6">
                                                <label class="m-0 font-weight-bold text-info" for="">Precio Bs.-: </label>
                                                <input type="text" value="<?php echo $precio;?>"  class="form-control form-control-user" id="precio" name="precio" require readonly
                                                 placeholder="Bs.-">
                                        </div>
                                    </div>

                                        <div class="col-sm-12">
                                        <label class="m-0 font-weight-bold text-info" for="">Precio Total Bs.-:
                                            <input type="text" class="form-control form-control-user" id="precioTotal" name="precioTotal" readonly require
                                                placeholder="Bs.-"> </label>

                                        </div>
                                    <!-- asta esta posicion  -->
                                    <div >
                                                <!-- <label class="m-0 font-weight-bold text-info" for="">Datos del Cliente:</label> -->

                                                    <!-- <div class="form-group">
                                                <input type="text" class="form-control form-control-user" id="nombres" name="nombres" require minlength="3"  maxlength="30"    pattern='[A-Za-z]{3,25}'
                                                    placeholder="Nombre">
                                                </div> -->

                                                <!-- <div class="form-group">
                                                    <input type="text" class="form-control form-control-user" id="apellido" name="apellidos" require minlength="3"  maxlength="30"    pattern='[A-Za-z]{3,25}'
                                                        placeholder="Apellido">
                                                </div> -->

                                                <!-- <div class="form-group row">
                                                    <div class="col-sm-6 mb-3 mb-sm-0">
                                                        <input type="text" class="form-control form-control-user" id="ci" name="ci" require  minlength="4"  maxlength="12" is_unique:[usuario.ci]
                                                            placeholder="C.I.">
                                                    </div>
                                                    <div class="col-sm-6">
                                                        <input type="number" class="form-control form-control-user" id="telefono" name="telefono" require min="1"  pattern='^[0-9]+'   minlength="7"  maxlength="8"
                                                            placeholder="Telefono">
                                                    </div>
                                                </div> -->
                                                <!-- <div class="form-group">
                                                    <input type="email" class="form-control form-control-user" id="correo" name="correo"
                                                        placeholder="Correo">
                                                </div> -->




                                <hr>

                            </form>

                                    </div>
                                    <div class="m-0 font-weight-bold text-info" class="form-group" aling="center">
                                            <?php
                                            echo date("Y-m-d H:i:s");
                                            ?>
                                    </div>
                                    <div class="mt-2 text-center small">
                                  

                                        <button id ="venta" type="submit" class="btn btn-primary" >VENTA</button>
                                        <!-- <button type="submit" class="btn btn-outline-primary" >RESERVA</button> -->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>     
                    
                    <?php
     $cont=  json_encode($sillas);
   
      print($cont);                                                 
       


?> 
           
      <!-- asta aca veremso q pasa -->
      <!-- ################################################################################################ -->
    </div>
  </div>
  <!-- ################################################################################################ -->
</div>

<script >
//  var data = <?php echo json_encode($sillas);?>;
 var seats = <?php echo json_encode($sillas);?>;

//para luego proceder al pintado en caso de q no este reservada

// var silla = document.getElementById("silla10")
// seats[4].name=="Null" ? silla.style.fill="white" : silla.style.fill="greenyellow";



  var elementos = document.getElementsByClassName("silla");
  for (let i = 0; i < elementos.length; i++) {
    if(seats[i].estado == 0     ){
      elementos[i].style.fill = "red";
    } else {
      elementos[i].style.fill = "white";
    }
    
  }

 
</script>



<!-- End Top Background Image Wrapper -->
<!-- ################################################################################################ -->

<!-- ################################################################################################ -->

<!-- asta aca -->


           
