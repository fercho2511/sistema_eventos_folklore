


function reload(segs) {

    setTimeout(function() {

        location.reload();

    }, parseInt(segs) * 5);

}

