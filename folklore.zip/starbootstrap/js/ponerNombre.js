// var titleCreate = svg.selectAll("#silla10").append("title").text("tooltip");
  // var textNazivaGradova = "hola mundoooooo"
  // var title = svg.getElementsByTagName("title");
  // title[i].innerHTML = textNazivaGradova;  


  // document.getElementsByName(#silla1).$(selector).append(content);
  // $(silla1).append(title).text("");

  
 
    
