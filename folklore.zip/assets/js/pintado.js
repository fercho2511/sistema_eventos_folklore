
var array_especificaciones = <?php echo json_encode($array_especificaciones) ?>;
// var seats = [
//   {
//     name: "Adrián Ceniza",
//     seat: 1
//   },
//   {
//     name: "Antonio Gil",
//     seat: 2
//   },
//   {
//     name: "Adrián Lorenzo",
//     seat: 3
//   },
//   {
//     name: "felipe",
//     seat: 4
//   },
//   {
//     name: "felipe",
//     seat: 5
//   },
//   {
//     name: "felipe",
//     seat: 6
//   },
//   {
//     name: "Null",
//     seat: 7
//   },
//   {
//     name: "Null",
//     seat: 8
//   },
//   {
//     name: "Null",
//     seat: 9
//   },
//   {
//     name: "Null",
//     seat: 10
//   },
//   {
//     name: "Null",
//     seat: 11
//   },
//   {
//     name: "Null",
//     seat: 12
//   },
//   {
//     name: "felipe",
//     seat: 13
//   },
//   {
//     name: "Null",
//     seat: 14
//   },
//   {
//     name: "Null",
//     seat: 15
//   },
//   {
//     name: "Null",
//     seat: 16
//   }
// ];

// //para luego proceder al pintado en caso de q no este reservada

// // var silla = document.getElementById("silla10")
// // seats[4].name=="Null" ? silla.style.fill="white" : silla.style.fill="greenyellow";



//   var elementos = document.getElementsByClassName("silla");
//   for (let i = 0; i < elementos.length; i++) {
//     if(seats[i].name == "Null"){
//       elementos[i].style.fill = "white";
//     } else {
//       elementos[i].style.fill = "red";
//     }
    
//   }

 